public class arraylist<T> {
	Object array[];
	int length=0;
	public arraylist() {
		this.array=new Object[50];
	}
	public void add(T element) {
		if((this.array.length)-length<25) {
			handleadd();
		}
		this.array[length]=element;
		length++;
	}
	
	private void handleadd() {
		Object[] newarray=new Object[2*(this.array.length)];
		for(int i=0;i<length;i++) {
			newarray[i]=this.array[i];
		}
		this.array=newarray;
	}
	public T get(int i) {
		if(i<length) {
			return (T) this.array[i];
		}
		else {
			throw new ArrayIndexOutOfBoundsException();
		}
		
	}
	public int size() {
		return this.length;
	}
	public void remove(int i) {
		if(i<length) {
			if(i==(length-1)) {
				this.array[i]=null;
				return;
			}
			for(int j=i;j<length-1;j++) {
				this.array[j]=this.array[j+1];
			}
			this.array[length-1]=null;
			length--;
			
		}
		else {
			throw new ArrayIndexOutOfBoundsException();
		}
	}
	public int getindex(T element) {
		 for(int j=0;j<length;j++) {
			 if((this.array[j]).equals(element)) {
				 return j;
			 }
		 }
        return -1;
       
}
	public boolean contains(T element) {
		for(int j=0;j<length;j++) {
			 if((this.array[j]).equals(element)) {
				 return true;
			 }
		 }
		return false;
	}
	public void set(int k,T element) {
		this.array[k]=element;
	}
	
	//public void insert()
	
	public static void main(String args[]) {
		/*arraylist<Integer> li = new arraylist<Integer>();
		li.add(4);
		li.add(9);
		li.add(6);
		li.add(9);
		li.add(0);
		li.add(12);
		li.add(90);
		li.add(89);
		for(int i=0;i<li.size();i++) {
			System.out.print(li.get(i)+" ");
		}
		System.out.println();
		System.out.println(li.size());
		System.out.println(li.getindex(9));
		li.remove(1);
		for(int i=0;i<li.size();i++) {
			System.out.print(li.get(i)+" ");
		}
		System.out.println();
		System.out.println(li.size());
		System.out.println(li.contains(6));
		System.out.println(li.contains(34));
		li.set(2,3);
		System.out.println(li.get(2));*/
		boolean my=true;
		if(my=true) {
			System.out.println(2);
		}
		else {
			System.out.println(3);
		}
	}
	
}
