public class Shape implements ShapeInterface {
	
	//INPUT [x1,y1,z1,x2,y2,z2,x3,y3,z3]
	arraylist<Point> allpoints = new arraylist<Point>();
	arraylist<Edge> alledges = new arraylist<Edge>();
	arraylist<Triangle> alltriangles = new arraylist<Triangle>();
	int v;
	 public boolean ADD_TRIANGLE(float [] triangle_coord){
		 Point P1 = new Point(triangle_coord[0],triangle_coord[1],triangle_coord[2]);
		 Point P2 = new Point(triangle_coord[3],triangle_coord[4],triangle_coord[5]);
		 Point P3 = new Point (triangle_coord[6],triangle_coord[7],triangle_coord[8]);
		 Edge E1 = new Edge(P1,P2);
		 Edge E11 = new Edge(P2,P1);
		 Edge E2 = new Edge(P2,P3);
		 Edge E22 = new Edge(P3,P2);
		 Edge E3 = new Edge(P3,P1);
		 Edge E33 = new Edge(P1,P3);
		
		 //System.out.println(alledges.size());
		 double l1 =distance(P1,P2);
		 double l2 = distance(P2,P3);
		 double l3 = distance(P3,P1);
		 
		 if(((l1+l2)==l3)|((l2+l3)==l1)|((l3+l1)==l2)) {
			 return false;
		 }
		 
		 else {
			 if(!contains1(P1,allpoints)) {
				 allpoints.add(P1);
			 }
			 //System.out.println( allpoints.contains(P1));
			 if(!contains1(P2,allpoints)) {
				 allpoints.add(P2);
			 }
			 if(!contains1(P3,allpoints)) {
				 allpoints.add(P3);
			 }
			 //System.out.println(allpoints.size());
			 
			 if(!contains2(E1,alledges)&&(!contains2(E11,alledges))) {
				 E1.priority=alledges.size();
				 alledges.add(E1);
			 }
			 if(!contains2(E2,alledges)&&(!contains2(E22,alledges))) {
				 E2.priority=alledges.size();
				 alledges.add(E2);
			 }
			 if(!contains2(E3,alledges)&&(!contains2(E33,alledges))) {
				 E3.priority=alledges.size();
				 alledges.add(E3);
			 }
			 Triangle T1 = new Triangle(P1,P2,P3);
			 T1.edges[0]=E1;
			 T1.edges[1]=E2;
			 T1.edges[2]=E3;
			 T1.edges[3]=E11;
			 T1.edges[4]=E22;
			 T1.edges[5]=E33;
			 T1.priority=(alltriangles.size())+1;
			 alltriangles.add(T1);
			 
			 //System.out.println(alltriangles.size());
			 /*for(int k=0;k<alltriangles.size();k++) {
				 System.out.println(alltriangles.get(k).point1().xcoordinate+" "+alltriangles.get(k).point1().ycoordinate+" "+alltriangles.get(k).point1().zcoordinate+" "+alltriangles.get(k).point2().xcoordinate+" "+alltriangles.get(k).point2().ycoordinate+" "+alltriangles.get(k).point2().zcoordinate+" "+alltriangles.get(k).point3().xcoordinate+" "+alltriangles.get(k).point3().ycoordinate+" "+alltriangles.get(k).point3().zcoordinate);
			 }*/
			 return true;
		 }
		
		 }
  public double distance(Point p1,Point p2) {
	  double k = ((p1.xcoordinate-p2.xcoordinate)*(p1.xcoordinate-p2.xcoordinate))+((p1.ycoordinate-p2.ycoordinate)*(p1.ycoordinate-p2.ycoordinate))+((p1.zcoordinate-p2.zcoordinate)*(p1.zcoordinate-p2.zcoordinate));
	  return sqrt(k);
	  
  }
//INPUT [x1,y1,z1,x2,y2,z2,x3,y3,z3]
  public boolean triangleneighbours(Triangle a,Triangle b)
  {
	  if (a.edge1().compareedge(b.edge1()) &&a.edge2().compareedge(b.edge2())&&a.edge3().compareedge(b.edge3()) 
			 || a.edge1().compareedge(b.edge1()) &&a.edge2().compareedge(b.edge3())&&a.edge3().compareedge(b.edge2())
			||  a.edge1().compareedge(b.edge2()) &&a.edge2().compareedge(b.edge3())&&a.edge3().compareedge(b.edge1())
			||a.edge1().compareedge(b.edge2()) &&a.edge2().compareedge(b.edge1())&&a.edge3().compareedge(b.edge3())
			||a.edge1().compareedge(b.edge3()) &&a.edge2().compareedge(b.edge1())&&a.edge3().compareedge(b.edge2())
			||a.edge1().compareedge(b.edge3()) &&a.edge2().compareedge(b.edge2())&&a.edge3().compareedge(b.edge1()))
	  {
		  return true;
	  }
	  return false;
  }
 public Triangle [] NEIGHBORS_OF_TRIANGLE(float [] triangle_coord){
	// System.out.println(2);
	 
	 Point P1 = new Point(triangle_coord[0],triangle_coord[1],triangle_coord[2]);
	 Point P2 = new Point(triangle_coord[3],triangle_coord[4],triangle_coord[5]);
	 Point P3 = new Point (triangle_coord[6],triangle_coord[7],triangle_coord[8]);
	/* Triangle t = new Triangle(P1,P2,P3);
	 arraylist neighbortriangles = new arraylist();
	 int count = 0;
	 for (int i = 0 ; i < alltriangles.size();i++)
	 {
		 if (triangleneighbours(t,alltriangles.get(i)))
		 {
			 count++;
			 neighbortriangles.add(alltriangles.get(i));
		 }
	 }
	 if (count == 0)
	 {
		 return null;
	 }
	 Triangle[] tr = new Triangle[count]; 
	 for (int k = 0; k < count ; k++)
	 {
		 tr[k] =(Triangle) neighbortriangles.get(k); 
		 System.out.println(tr[k].point1().xcoordinate+","+tr[k].point1().ycoordinate+","+tr[k].point1().zcoordinate+",,"+tr[k].point2().xcoordinate+","+tr[k].point2().ycoordinate+","+tr[k].point2().zcoordinate+",,"+tr[k].point3().xcoordinate+","+tr[k].point3().ycoordinate+","+tr[k].point3().zcoordinate);
	 }*/
	 
	 arraylist neighbortriangles = new arraylist();
	 Triangle T1 = new Triangle(P1,P2,P3);
	 Triangle T2 = new Triangle(P1,P3,P2);
	 Triangle T3 = new Triangle(P2,P1,P3);
	 Triangle T4 = new Triangle(P2,P3,P1);
	 Triangle T5 = new Triangle(P3,P2,P1);
	 Triangle T6 = new Triangle(P3,P1,P2);
	 if(contains3(T1,alltriangles)||contains3(T2,alltriangles)||contains3(T3,alltriangles)||contains3(T4,alltriangles)||contains3(T5,alltriangles)||contains3(T6,alltriangles)) {
		//System.out.println(2);
		 for(int i =0;i<alltriangles.size();i++) {
			 //System.out.println(2);
			 if(((equal(alltriangles.get(i).point1(),P1))||(equal(alltriangles.get(i).point2(),P1))||(equal(alltriangles.get(i).point3(),P1)))&&(((equal(alltriangles.get(i).point1(),P2)))||(equal(alltriangles.get(i).point2(),P2))||((equal(alltriangles.get(i).point3(),P2))))) {
				 neighbortriangles.add(alltriangles.get(i));//System.out.println(2);
			 }
			 if(((equal(alltriangles.get(i).point1(),P2))||(equal(alltriangles.get(i).point2(),P2))||(equal(alltriangles.get(i).point3(),P2)))&&(((equal(alltriangles.get(i).point1(),P3)))||(equal(alltriangles.get(i).point2(),P3))||((equal(alltriangles.get(i).point3(),P3))))) {
				 neighbortriangles.add(alltriangles.get(i));//System.out.println(2);
			 }
			 if(((equal(alltriangles.get(i).point1(),P1))||(equal(alltriangles.get(i).point2(),P1))||(equal(alltriangles.get(i).point3(),P1)))&&(((equal(alltriangles.get(i).point1(),P3)))||(equal(alltriangles.get(i).point2(),P3))||((equal(alltriangles.get(i).point3(),P3))))) {
				 neighbortriangles.add(alltriangles.get(i));//System.out.println(2);
			 }
		 }
		

		 arraylist sortedneighbors = sorting2(neighbortriangles,P1,P2,P3);
		 int k =  sortedneighbors.size();
		 Triangle[] neighbors = new Triangle[k];
		 for(int l =0;l<k;l++) {
			 neighbors[l]=(Triangle) sortedneighbors.get(l);
		 }
		 //System.out.println(sortedneighbors.size());
		/* for(int h=0;h<neighbors.length;h++) {
			 System.out.println(neighbors[h].point1().xcoordinate+","+neighbors[h].point1().ycoordinate+","+neighbors[h].point1().zcoordinate+",,"+neighbors[h].point2().xcoordinate+","+neighbors[h].point2().ycoordinate+","+neighbors[h].point2().zcoordinate+",,"+neighbors[h].point3().xcoordinate+","+neighbors[h].point3().ycoordinate+","+neighbors[h].point3().zcoordinate);
		 }*/
		// System.out.println(2);
		 return neighbors;
		 
	 }
	return null;
	 }
	 
	 
	 
    public arraylist<Triangle> sorting(arraylist<Triangle> a) {
    	for(int i=0;i<a.size()-1;i++) {
    		for(int j =0;j<a.size()-i-1;j++) {
    			if(a.get(i).priority>a.get(i+1).priority) {
    				Triangle ch = a.get(j);
    				Triangle ch2 = a.get(j+1);
    				a.set(j,ch2);
    				a.set(j+1, ch);
    			}
    		}
    	}
    	return a;
    	
    }
    public arraylist<Triangle> sorting2(arraylist<Triangle> b,Point P1,Point P2,Point P3){
    Triangle T1 = new Triangle(P1,P2,P3);
   	 Triangle T2 = new Triangle(P1,P3,P2);
   	 Triangle T3 = new Triangle(P2,P1,P3);
   	 Triangle T4 = new Triangle(P2,P3,P1);
   	 Triangle T5 = new Triangle(P3,P2,P1);
   	 Triangle T6 = new Triangle(P3,P1,P2);
   	 int k=0;
   	 arraylist<Triangle> emi = new arraylist();
    	while (k<b.size()) {
    		//System.out.println(2);
    		if((!equaltri(b.get(k),T1))&&(!equaltri(b.get(k),T2))&&(!equaltri(b.get(k),T3))&&(!equaltri(b.get(k),T4))&&(!equaltri(b.get(k),T5))&&(!equaltri(b.get(k),T6))){
    			emi.add(b.get(k));
    		}
    		k++;
    	}
    	//System.out.println(emi.size());
    	for(int i=0;i<emi.size()-1;i++) {
    		for(int j =0;j<emi.size()-i-1;j++) {
    			if(emi.get(i).priority>emi.get(i+1).priority) {
    				Triangle ch = emi.get(j);
    				Triangle ch2 = emi.get(j+1);
    				emi.set(j,ch2);
    				emi.set(j+1, ch);
    			}
    		}
    	}
    	return emi;
    }
 // INPUT [x,y,z]
     public Point [] NEIGHBORS_OF_POINT(float [] point_coordinates){	 
    	 Point P = new Point(point_coordinates[0],point_coordinates[1],point_coordinates[2]);
    	 arraylist<Point> neighborpoints = new arraylist(); 
    	 if(contains1(P,allpoints)) {
    		 for(int k=0;k<alledges.size();k++) {
        		 if((alledges.get(k).Point1().xcoordinate)==(P.xcoordinate)&&(alledges.get(k).Point1().ycoordinate)==(P.ycoordinate)&&(alledges.get(k).Point1().zcoordinate)==(P.zcoordinate)&&(!neighborpoints.contains(alledges.get(k).Point2()))) {
        			 neighborpoints.add(alledges.get(k).Point2());
        			// System.out.println(1);
        		 }
        		 if((alledges.get(k).Point2().xcoordinate)==(P.xcoordinate)&&(alledges.get(k).Point2().ycoordinate)==(P.ycoordinate)&&(alledges.get(k).Point2().zcoordinate)==(P.zcoordinate)&&(!neighborpoints.contains(alledges.get(k).Point1()))) {
        			 neighborpoints.add(alledges.get(k).Point1());
        			// System.out.println(2);
        		 }
        	 }
        	 int g=neighborpoints.size();
        	 /*for (int lio=0;lio<neighborpoints.size();lio++) {
        		 System.out.println(neighborpoints.get(lio).xcoordinate+" "+neighborpoints.get(lio).ycoordinate+" "+neighborpoints.get(lio).zcoordinate);
        	 }*/
        	 Point[] neighborarray=new Point[g];
        	 int h=0;
        	 while(h<g) {
        		 Point t=neighborpoints.get(h);
        		 neighborarray[h]=t;
        		 h++;
        		// System.out.println(h);
        	 }
        	// System.out.println(neighborarray);
        	 return neighborarray;
    	 }
    	 else {
    		 return null;
    	 }
    	 }
  // INPUT[x,y,z]
 public EdgeInterface [] EDGE_NEIGHBORS_OF_POINT(float [] point_coordinates){
	 Point P = new Point(point_coordinates[0],point_coordinates[1],point_coordinates[2]);
	 arraylist<Edge> edgeneighbors = new arraylist<Edge>();
	 if(contains1(P,allpoints)) {
		 for(int k=0;k<alledges.size();k++) {
			 if((alledges.get(k).Point1().xcoordinate)==(P.xcoordinate)&&(alledges.get(k).Point1().ycoordinate)==(P.ycoordinate)&&(alledges.get(k).Point1().zcoordinate)==(P.zcoordinate)) {
				 edgeneighbors.add(alledges.get(k)); 
				// System.out.println(1);
			 }
			 if((alledges.get(k).Point2().xcoordinate)==(P.xcoordinate)&&(alledges.get(k).Point2().ycoordinate)==(P.ycoordinate)&&(alledges.get(k).Point2().zcoordinate)==(P.zcoordinate)) {
				 edgeneighbors.add(alledges.get(k)); 
				// System.out.println(2);
			 }
		 }
			 int f =edgeneighbors.size();
			// System.out.println(f);
			 Edge[] edgearray=new Edge[f];
	          for(int y=0;y<f;y++) {
	        	  edgearray[y]=edgeneighbors.get(y);
	          }
		 return edgearray;
		 
	 }
	 else {
		 return null;
	 }
	 }
//INPUT[x,y,z]
public TriangleInterface [] FACE_NEIGHBORS_OF_POINT(float [] point_coordinates){ 
	Point P = new Point(point_coordinates[0],point_coordinates[1],point_coordinates[2]);
	arraylist<Triangle> neighbortriangles = new arraylist<Triangle>();
	if(contains1(P,allpoints)) {
		for (int c=0;c<alltriangles.size();c++) {
			if((alltriangles.get(c).point1().xcoordinate==P.xcoordinate)&&(alltriangles.get(c).point1().ycoordinate==P.ycoordinate)&&(alltriangles.get(c).point1().zcoordinate==P.zcoordinate)) {
				neighbortriangles.add(alltriangles.get(c));
			}
			if((alltriangles.get(c).point2().xcoordinate==P.xcoordinate)&&(alltriangles.get(c).point2().ycoordinate==P.ycoordinate)&&(alltriangles.get(c).point2().zcoordinate==P.zcoordinate)) {
				neighbortriangles.add(alltriangles.get(c));
			}
			if((alltriangles.get(c).point3().xcoordinate==P.xcoordinate)&&(alltriangles.get(c).point3().ycoordinate==P.ycoordinate)&&(alltriangles.get(c).point3().zcoordinate==P.zcoordinate)) {
				neighbortriangles.add(alltriangles.get(c));
			}
		}
		int v =neighbortriangles.size();
		arraylist ded=sorting(neighbortriangles);
		Triangle[] faceneighborarray= new Triangle [v];
		for(int by=0;by<v;by++) {
			faceneighborarray[by]=(Triangle) ded.get(by);
		}
		//System.out.println(faceneighborarray.length);
		/*for(int gt =0;gt<faceneighborarray.length;gt++) {
	System.out.println(faceneighborarray[gt].point1().xcoordinate+","+faceneighborarray[gt].point1().ycoordinate+","+faceneighborarray[gt].point1().zcoordinate+",,"+faceneighborarray[gt].point2().xcoordinate+","+faceneighborarray[gt].point2().ycoordinate+","+faceneighborarray[gt].point2().zcoordinate+",,"+faceneighborarray[gt].point3().xcoordinate+","+faceneighborarray[gt].point3().ycoordinate+","+faceneighborarray[gt].point3().zcoordinate);
		}*/
		return faceneighborarray;
		
	}
	else {
		return null;
	}
	
	}

//INPUT [x,y,z]
 public TriangleInterface [] INCIDENT_TRIANGLES(float [] point_coordinates){
	 Point P = new Point(point_coordinates[0],point_coordinates[1],point_coordinates[2]);
		arraylist<Triangle> neighbortriangles = new arraylist<Triangle>();
		if(contains1(P,allpoints)) {
			for (int c=0;c<alltriangles.size();c++) {
				if((alltriangles.get(c).point1().xcoordinate==P.xcoordinate)&&(alltriangles.get(c).point1().ycoordinate==P.ycoordinate)&&(alltriangles.get(c).point1().zcoordinate==P.zcoordinate)) {
					neighbortriangles.add(alltriangles.get(c));
				}
				if((alltriangles.get(c).point2().xcoordinate==P.xcoordinate)&&(alltriangles.get(c).point2().ycoordinate==P.ycoordinate)&&(alltriangles.get(c).point2().zcoordinate==P.zcoordinate)) {
					neighbortriangles.add(alltriangles.get(c));
				}
				if((alltriangles.get(c).point3().xcoordinate==P.xcoordinate)&&(alltriangles.get(c).point3().ycoordinate==P.ycoordinate)&&(alltriangles.get(c).point3().zcoordinate==P.zcoordinate)) {
					neighbortriangles.add(alltriangles.get(c));
				}
			}
			int v =neighbortriangles.size();
			arraylist ded=sorting(neighbortriangles);
			Triangle[] faceneighborarray= new Triangle [v];
			for(int by=0;by<v;by++) {
				faceneighborarray[by]=(Triangle) ded.get(by);
			}
			//System.out.println(faceneighborarray.length);
			/*for(int gt =0;gt<faceneighborarray.length;gt++) {
		System.out.println(faceneighborarray[gt].point1().xcoordinate+","+faceneighborarray[gt].point1().ycoordinate+","+faceneighborarray[gt].point1().zcoordinate+",,"+faceneighborarray[gt].point2().xcoordinate+","+faceneighborarray[gt].point2().ycoordinate+","+faceneighborarray[gt].point2().zcoordinate+",,"+faceneighborarray[gt].point3().xcoordinate+","+faceneighborarray[gt].point3().ycoordinate+","+faceneighborarray[gt].point3().zcoordinate);
			}*/
			return faceneighborarray;
			
		}
		else {
			return null;
		}
		
	 
	 }
//INPUT [x1,y1,z1,x2,y2,z2] // where (x1,y1,z1) refers to first end point of edge and  (x2,y2,z2) refers to the second.
 public TriangleInterface [] TRIANGLE_NEIGHBOR_OF_EDGE(float [] edge_coordinates){ 
	 Point P1 = new Point(edge_coordinates[0],edge_coordinates[1],edge_coordinates[2]);
	 Point P2 = new Point(edge_coordinates[3],edge_coordinates[4],edge_coordinates[5]);
	 arraylist tri = new arraylist();
	 Edge E1 = new Edge(P1,P2);
	 Edge E11 = new Edge(P2,P1);
	 if((contains2(E1,alledges))||(contains2(E11,alledges))){
		 for(int gu = 0;gu<alltriangles.size();gu++) {
            if(equal(alltriangles.get(gu).point1(),P1)&&equal(alltriangles.get(gu).point2(),P2)) {
	            tri.add(alltriangles.get(gu));
                }
            if(equal(alltriangles.get(gu).point1(),P2)&&equal(alltriangles.get(gu).point2(),P1)) {
	            tri.add(alltriangles.get(gu));
                }
            if(equal(alltriangles.get(gu).point2(),P1)&&equal(alltriangles.get(gu).point3(),P2)) {
	            tri.add(alltriangles.get(gu));
                }
            if(equal(alltriangles.get(gu).point2(),P2)&&equal(alltriangles.get(gu).point3(),P1)) {
	            tri.add(alltriangles.get(gu));
                }
            if(equal(alltriangles.get(gu).point1(),P1)&&equal(alltriangles.get(gu).point3(),P2)) {
	            tri.add(alltriangles.get(gu));
                }
            if(equal(alltriangles.get(gu).point1(),P2)&&equal(alltriangles.get(gu).point3(),P1)) {
	            tri.add(alltriangles.get(gu));
                }
		 }
	int cv = tri.size();
	arraylist red = sorting(tri);
 Triangle[]  arr=new Triangle[cv];
 for (int tv=0;tv<cv;tv++) {
	 arr[tv]=(Triangle) red.get(tv);
      }
 /*for (int h=0 ; h<cv;h++) {
	 System.out.println(arr[h].point1().xcoordinate+","+arr[h].point1().ycoordinate+","+arr[h].point1().zcoordinate+",,"+arr[h].point2().xcoordinate+","+arr[h].point2().ycoordinate+","+arr[h].point2().zcoordinate+",,"+arr[h].point3().xcoordinate+","+arr[h].point3().ycoordinate+","+arr[h].point3().zcoordinate);	 
 }*/
     return arr;
	 }
	 
	 else {
		 return null;	 
	 }
	 }

//INPUT [x1,y1,z1,x2,y2,z2,x3,y3,z3]
 public EdgeInterface [] EDGE_NEIGHBOR_TRIANGLE(float [] triangle_coord){
	 Point P1 = new Point(triangle_coord[0],triangle_coord[1],triangle_coord[2]);
	 Point P2 = new Point(triangle_coord[3],triangle_coord[4],triangle_coord[5]);
	 Point P3 = new Point (triangle_coord[6],triangle_coord[7],triangle_coord[8]);
	 Triangle T1 = new Triangle(P1,P2,P3);
	 Triangle T2 = new Triangle(P1,P3,P2);
	 Triangle T3 = new Triangle(P2,P1,P3);
	 Triangle T4 = new Triangle(P2,P3,P1);
	 Triangle T5 = new Triangle(P3,P2,P1);
	 Triangle T6 = new Triangle(P3,P1,P2);
	 Edge E1 = new Edge(P1,P2);
	 Edge E11 = new Edge(P2,P1);
	 Edge E2 = new Edge(P2,P3);
	 Edge E22 = new Edge(P3,P2);
	 Edge E3 = new Edge(P3,P1);
	 Edge E33 = new Edge(P1,P3);
	 Edge[] edg = new Edge[3];
	 if((!(contains3(T1,alltriangles))&&(!contains3(T2,alltriangles))&&(!contains3(T3,alltriangles))&&(!contains3(T4,alltriangles))&&(!contains3(T5,alltriangles))&&(!contains3(T6,alltriangles)))) {
		return null; 
		 }
		 
	 else {
		 if((contains2(E1,alledges))&&(!(contains2(E11,alledges)))){
			 edg[0]=E1;
		 }
		 if((!(contains2(E1,alledges)))&&(contains2(E11,alledges))) {
			 edg[0]=E11;
		 }
		 if((contains2(E2,alledges))&&(!(contains2(E22,alledges)))){
			 edg[1]=E2;
		 }
		 if((!(contains2(E2,alledges)))&&(contains2(E22,alledges))) {
			 edg[1]=E22;
		 }
		 if((contains2(E3,alledges))&&(!(contains2(E33,alledges)))){
			 edg[2]=E3;
		 }
		 if((!(contains2(E3,alledges)))&&(contains2(E33,alledges))) {
			 edg[2]=E33;
		 }
		 /*for(int yr=0;yr<3;yr++) {
			 System.out.println(edg[yr].Point1().xcoordinate+","+edg[yr].Point1().ycoordinate+","+edg[yr].Point1().zcoordinate+"  "+edg[yr].Point2().xcoordinate+","+edg[yr].Point2().ycoordinate+","+edg[yr].Point2().zcoordinate);
		 }*/
		 return edg;
	 }
	 }
  
     
//INPUT [x1,y1,z1,x2,y2,z2,x3,y3,z3]
 public PointInterface [] VERTEX_NEIGHBOR_TRIANGLE(float [] triangle_coord){
	 Point P1 = new Point(triangle_coord[0],triangle_coord[1],triangle_coord[2]);
	 Point P2 = new Point(triangle_coord[3],triangle_coord[4],triangle_coord[5]);
	 Point P3 = new Point (triangle_coord[6],triangle_coord[7],triangle_coord[8]);
	 Triangle T1 = new Triangle(P1,P2,P3);
	 Triangle T2 = new Triangle(P1,P3,P2);
	 Triangle T3 = new Triangle(P2,P1,P3);
	 Triangle T4 = new Triangle(P2,P3,P1);
	 Triangle T5 = new Triangle(P3,P2,P1);
	 Triangle T6 = new Triangle(P3,P1,P2);
	 Point[] fgh = new Point[3];
	// System.out.println(contains3(T1,alltriangles));
	// System.out.println(equal(P2,P3));
	 if((!(contains3(T1,alltriangles))&&(!contains3(T2,alltriangles))&&(!contains3(T3,alltriangles))&&(!contains3(T4,alltriangles))&&(!contains3(T5,alltriangles))&&(!contains3(T6,alltriangles)))) {
		return null; 
	 }
	 
	 else {
		 fgh[0]= P1;
		 fgh[1]=P2;
		 fgh[2]=P3;
		/* for(int j=0;j<3;j++) {
		System.out.println(fgh[j].xcoordinate+","+fgh[j].ycoordinate+","+fgh[j].zcoordinate);
		 }*/
		 return fgh;
		 
	 }
	 
	 }
//INPUT [x1,y1,z1,x2,y2,z2,x3,y3,z3]
 public TriangleInterface [] EXTENDED_NEIGHBOR_TRIANGLE(float [] triangle_coord){
	 Point P1 = new Point(triangle_coord[0],triangle_coord[1],triangle_coord[2]);
	 Point P2 = new Point(triangle_coord[3],triangle_coord[4],triangle_coord[5]);
	 Point P3 = new Point (triangle_coord[6],triangle_coord[7],triangle_coord[8]);
	 Triangle T1 = new Triangle(P1,P2,P3);
	 Triangle T2 = new Triangle(P1,P3,P2);
	 Triangle T3 = new Triangle(P2,P1,P3);
	 Triangle T4 = new Triangle(P2,P3,P1);
	 Triangle T5 = new Triangle(P3,P2,P1);
	 Triangle T6 = new Triangle(P3,P1,P2);
	 arraylist<Triangle> req = new <Triangle>arraylist();
	 if((!(contains3(T1,alltriangles))&&(!contains3(T2,alltriangles))&&(!contains3(T3,alltriangles))&&(!contains3(T4,alltriangles))&&(!contains3(T5,alltriangles))&&(!contains3(T6,alltriangles)))) {
			return null; 
		 }
	 else{
	for(int y=0;y<alltriangles.size();y++) {
		if(((equal(P1,alltriangles.get(y).point1()))||(equal(P1,alltriangles.get(y).point2()))||(equal(P1,alltriangles.get(y).point3())))&&(!contains3(alltriangles.get(y),req))) {
			req.add(alltriangles.get(y));
		}
		if(((equal(P2,alltriangles.get(y).point1()))||(equal(P2,alltriangles.get(y).point2()))||(equal(P2,alltriangles.get(y).point3())))&&(!contains3(alltriangles.get(y),req))) {
			req.add(alltriangles.get(y));
		}
		if(((equal(P3,alltriangles.get(y).point1()))||(equal(P3,alltriangles.get(y).point2()))||(equal(P3,alltriangles.get(y).point3())))&&(!contains3(alltriangles.get(y),req))) {
			req.add(alltriangles.get(y));
		}
	}
	arraylist<Triangle> thy = sorting2( req,P1,P2,P3);
	 int k =  thy.size();
	 Triangle[] oiu = new Triangle[k];
	 for(int g=0;g<k;g++) {
		 oiu[g]= thy.get(g);
	 }
	 /*for (int f=0;f<oiu.length;f++) {
		 System.out.println(oiu[f].point1().xcoordinate+","+oiu[f].point1().ycoordinate+","+oiu[f].point1().zcoordinate+"  "+oiu[f].point2().xcoordinate+","+oiu[f].point2().ycoordinate+","+oiu[f].point2().zcoordinate+"  "+oiu[f].point3().xcoordinate+","+oiu[f].point3().ycoordinate+","+oiu[f].point3().zcoordinate);
	 }*/
	 return oiu;
	}
 } 
 public EdgeInterface [] BOUNDARY_EDGES(){
	 //System.out.println(alledges.size());
	 arraylist<Edge> boundaryedges = new<Edge> arraylist();
	 
	 for(int i=0;i<alledges.size();i++) {
		 Edge e1 = alledges.get(i);
		 Point p1=e1.Point1();
		 Point p2 = e1.Point2();
		 Edge e2 = new Edge(p2,p1);
		 arraylist<Triangle> containedtriangles =new<Triangle> arraylist();
		 for(int h=0;h<alltriangles.size();h++) {
			 Triangle t1= alltriangles.get(h);
			 if((equaledge(t1.edges[0],e1))||(equaledge(t1.edges[1],e1))||(equaledge(t1.edges[2],e1))||(equaledge(t1.edges[3],e1))||(equaledge(t1.edges[4],e1))||(equaledge(t1.edges[5],e1))) {
				 containedtriangles.add(t1);
			 } 
		 }
		 //System.out.println( containedtriangles.size());
		 if(containedtriangles.size()==1) {
			 boundaryedges.add(e1);
		 }
		 
	 }
	 int v = boundaryedges.size();
	 if (v == 0)
	 {
		 //System.out.println("null");
		 return null;
	 }
	 arraylist<Edge> edg = sortingedges(boundaryedges);
	 Edge[] boundaryedge=new Edge [v];
	 for (int k =0;k<v;k++) {
		 boundaryedge[k]=edg.get(k);
	 }
	 //System.out.println(boundaryedge.length );
	/*for(int g =0;g<boundaryedge.length;g++) {
System.out.println(boundaryedge[g].Point1().xcoordinate+","+boundaryedge[g].Point1().ycoordinate+","+boundaryedge[g].Point1().zcoordinate+",,,"+boundaryedge[g].Point2().xcoordinate+","+boundaryedge[g].Point2().ycoordinate+","+boundaryedge[g].Point2().zcoordinate);
	 }*/
	 return boundaryedge;
	 }   
 public int TYPE_MESH(){
	 arraylist<Edge> propermesh = new arraylist<Edge>();
	 arraylist<Edge> semiproper = new arraylist<Edge>();
	 arraylist<Edge> improper = new arraylist<Edge>();
	 
	 for(int i=0;i<alledges.size();i++) {
		 Edge e1 = alledges.get(i);
		 Point p1=e1.Point1();
		 Point p2 = e1.Point2();
		 Edge e2 = new Edge(p2,p1);
		 arraylist<Triangle> containedtriangles =new<Triangle> arraylist();
		 for(int h=0;h<alltriangles.size();h++) {
			 Triangle t1= alltriangles.get(h);
			 if((equaledge(t1.edges[0],e1))||(equaledge(t1.edges[1],e1))||(equaledge(t1.edges[2],e1))||(equaledge(t1.edges[3],e1))||(equaledge(t1.edges[4],e1))||(equaledge(t1.edges[5],e1))) {
				 containedtriangles.add(t1);
			 } 
			 //System.out.println( containedtriangles.size());
		 }
		 if(containedtriangles.size()==2) {
			 propermesh.add(e1);
			 
		 }
		 if(containedtriangles.size()>2) {
			 improper.add(e1);
		 }
		 if(containedtriangles.size()==1) {
			 semiproper.add(e1);
		 }
	 }
	 if(propermesh.size()==alledges.size()) {
		 return 1;
	 }
	 else if(improper.size()>0) {
		 return 3;
	 }
	 else if((semiproper.size()>0)&&(semiproper.size()+propermesh.size()==alledges.size())){
		 return 2;
	 }
	 else {
		 return -1;
	 }
	
	 }   
     
     
public boolean contains1(Point r,arraylist<Point> hw) {
	for(int j=0;j<hw.size();j++) {
		if((r.xcoordinate==hw.get(j).xcoordinate)&&(r.ycoordinate==hw.get(j).ycoordinate)&&(r.zcoordinate==hw.get(j).zcoordinate)) {
			return true;
		}
	}
	return false;
}
public boolean contains2(Edge e,arraylist<Edge> je) {
	for(int g=0;g<je.size();g++) {
		if((e.Point1().xcoordinate==je.get(g).Point1().xcoordinate)&&(e.Point1().ycoordinate==je.get(g).Point1().ycoordinate)&&(e.Point1().zcoordinate==je.get(g).Point1().zcoordinate)&&(e.Point2().xcoordinate==je.get(g).Point2().xcoordinate)&&(e.Point2().ycoordinate==je.get(g).Point2().ycoordinate)&&(e.Point2().zcoordinate==je.get(g).Point2().zcoordinate)) {
			return true;
		}
	/*	else if((e.Point1().xcoordinate==je.get(g).Point2().xcoordinate)&&(e.Point1().ycoordinate==je.get(g).Point2().ycoordinate)&&(e.Point1().zcoordinate==je.get(g).Point2().zcoordinate)&&(e.Point2().xcoordinate==je.get(g).Point1().xcoordinate)&&(e.Point2().ycoordinate==je.get(g).Point1().ycoordinate)&&(e.Point2().zcoordinate==je.get(g).Point1().zcoordinate)) {
			return false;
		}*/
	}
	return false;
}
public boolean contains3(Triangle t,arraylist<Triangle> tg) {
	for(int u=0;u<tg.size();u++) {
if((t.point1().xcoordinate==tg.get(u).point1().xcoordinate)&&(t.point1().ycoordinate==tg.get(u).point1().ycoordinate)&&(t.point1().zcoordinate==tg.get(u).point1().zcoordinate)&&(t.point2().xcoordinate==tg.get(u).point2().xcoordinate)&&(t.point2().ycoordinate==tg.get(u).point2().ycoordinate)&&(t.point2().zcoordinate==tg.get(u).point2().zcoordinate)&&(t.point3().xcoordinate==tg.get(u).point3().xcoordinate)&&(t.point3().ycoordinate==tg.get(u).point3().ycoordinate)&&(t.point3().zcoordinate==tg.get(u).point3().zcoordinate)) {
	return true;
}
	}
	return false;
}
public boolean equal(Point P1,Point P2) {
	if((P1.xcoordinate==P2.xcoordinate)&&(P1.ycoordinate==P2.ycoordinate)&&(P1.zcoordinate==P2.zcoordinate)) {
		return true;
	}
	return false;
}
public boolean equaltri(Triangle T1,Triangle T2) {
	if((equal(T1.point1(),T2.point1()))&&(equal(T1.point2(),T2.point2()))&&(equal(T1.point3(),T2.point3()))){
		return true;
	}
	return false;
}
public boolean equaledge(Edge e1,Edge e2) {
	if((e1.Point1().xcoordinate==e2.Point1().xcoordinate)&&(e1.Point1().ycoordinate==e2.Point1().ycoordinate)&&(e1.Point1().zcoordinate==e2.Point1().zcoordinate)&&(e1.Point2().xcoordinate==e2.Point2().xcoordinate)&&(e1.Point2().ycoordinate==e2.Point2().ycoordinate)&&(e1.Point1().zcoordinate==e2.Point1().zcoordinate)) {
		return true;
	}
	return false;
}
public arraylist<Edge> sortingedges(arraylist<Edge> a){
	for(int i=0;i<a.size()-1;i++) {
		for(int j =0;j<a.size()-i-1;j++) {
			if((a.get(j).length>a.get(j+1).length)||((a.get(j).length==a.get(j+1).length)&&(a.get(j).priority>a.get(j+1).priority))) {
				Edge ch = a.get(j);
				Edge ch2 = a.get(j+1);
				a.set(j,ch2);
				a.set(j+1, ch);
			}
		}
	
}
	return a;
}
//INPUT // [xa1,ya1,za1,xa2,ya2,za2,xa3,ya3,za3 , xb1,yb1,zb1,xb2,yb2,zb2,xb3,yb3,zb3]   where xa1,ya1,za1,xa2,ya2,za2,xa3,ya3,za3 are 3 coordinates of first triangle and xb1,yb1,zb1,xb2,yb2,zb2,xb3,yb3,zb3 are coordinates of second triangle as given in specificaition.
 public boolean IS_CONNECTED(float [] triangle_coord_1, float [] triangle_coord_2){
	 Point Pa1 = new Point(triangle_coord_1[0],triangle_coord_1[1],triangle_coord_1[2]);
	 Point Pa2 = new Point(triangle_coord_1[3],triangle_coord_1[4],triangle_coord_1[5]);
	 Point Pa3 = new Point (triangle_coord_1[6],triangle_coord_1[7],triangle_coord_1[8]);
	 Triangle Ta1 = new Triangle(Pa1,Pa2,Pa3);
	 Triangle Ta2 = new Triangle(Pa1,Pa3,Pa2);
	 Triangle Ta3 = new Triangle(Pa2,Pa1,Pa3);
	 Triangle Ta4 = new Triangle(Pa2,Pa3,Pa1);
	 Triangle Ta5 = new Triangle(Pa3,Pa2,Pa1);
	 Triangle Ta6 = new Triangle(Pa3,Pa1,Pa2);
	 Point Pb1 = new Point(triangle_coord_2[0],triangle_coord_2[1],triangle_coord_2[2]);
	 Point Pb2 = new Point(triangle_coord_2[3],triangle_coord_2[4],triangle_coord_2[5]);
	 Point Pb3 = new Point (triangle_coord_2[6],triangle_coord_2[7],triangle_coord_2[8]);
	 Triangle Tb1 = new Triangle(Pb1,Pb2,Pb3);
	 Triangle Tb2 = new Triangle(Pb1,Pb3,Pb2);
	 Triangle Tb3 = new Triangle(Pb2,Pb1,Pb3);
	 Triangle Tb4 = new Triangle(Pb2,Pb3,Pb1);
	 Triangle Tb5 = new Triangle(Pb3,Pb2,Pb1);
	 Triangle Tb6 = new Triangle(Pb3,Pb1,Pb2);
	 if(((contains3(Ta1,alltriangles))||(contains3(Ta2,alltriangles))||(contains3(Ta3,alltriangles))||(contains3(Ta4,alltriangles))||(contains3(Ta5,alltriangles))||(contains3(Ta6,alltriangles)))&&((contains3(Tb1,alltriangles))||(contains3(Tb2,alltriangles))||(contains3(Tb3,alltriangles))||(contains3(Tb4,alltriangles))||(contains3(Tb5,alltriangles))||(contains3(Tb6,alltriangles)))) {
		 /*Queue<Triangle> gbd = new Queue(alltriangles.size());
		 Triangle f1=orderedtriangle( alltriangles,Pa1,Pa2, Pa3);
		(orderedtriangle( alltriangles,Pa1,Pa2, Pa3)).marked=true;
		 arraylist<Triangle> g = getneighbors(f1.point1(),f1.point2(),f1.point3());
		 for(int v=0;v<g.size();v++) {
			 g.get(v).marked=true;
			 gbd.enqueue(g.get(v));
		 }
		 while(!(gbd.isEmpty())) {
			 Triangle t = gbd.dequeue();
			 //t.marked=true;
			 if((equaltri(t,Tb1))||(equaltri(t,Tb2))||(equaltri(t,Tb3))||(equaltri(t,Tb4))||(equaltri(t,Tb5))||(equaltri(t,Tb6))) {
				 return true;
			 }
			 arraylist<Triangle> b = getneighbors(t.point1(),t.point2(),t.point3());
			 for(int f=0;f<b.size();f++) {
				 if(!(b.get(f).marked)) {
					 b.get(f).marked=true;
					 gbd.enqueue(b.get(f));
				 }
			 }
		 }
		 for(int h=0;h<alltriangles.size();h++) {
				alltriangles.get(h).marked=false;
			}
		 return false;*/
		 Queue<Triangle> ab = new<Triangle> Queue((alltriangles.size()));
		 Triangle T = orderedtriangle(alltriangles,Pa1,Pa2,Pa3);
		 T.marked=true;
		 ab.enqueue(T);
		 while(!ab.isEmpty()) {
			 Triangle t = ab.dequeue();
			 if((equaltri(t,Tb1))||(equaltri(t,Tb2))||(equaltri(t,Tb3))||(equaltri(t,Tb4))||(equaltri(t,Tb5))||(equaltri(t,Tb6))) {
				 for(int i=0;i<alltriangles.size();i++) {
					 alltriangles.get(i).marked=false;
				 }
				 return true;
			 }
			 else {
				 arraylist<Triangle> b = getneighbors(t.point1(),t.point2(),t.point3());
				 for(int h=0;h<b.size();h++) {
					 if(!(b.get(h).marked)) {
						 b.get(h).marked=true;
						 ab.enqueue(b.get(h));
					 }
				 }
			 }
		 }
		 for(int i=0;i<alltriangles.length;i++) {
			 alltriangles.get(i).marked=false;
		 }
		 
		 return false;
	 }
	 return false;
	 }


public arraylist<Triangle> getneighbors(Point P1,Point P2,Point P3){
	arraylist<Triangle> neighbortriangles = new arraylist();
	 Triangle T1 = new Triangle(P1,P2,P3);
	 Triangle T2 = new Triangle(P1,P3,P2);
	 Triangle T3 = new Triangle(P2,P1,P3);
	 Triangle T4 = new Triangle(P2,P3,P1);
	 Triangle T5 = new Triangle(P3,P2,P1);
	 Triangle T6 = new Triangle(P3,P1,P2);
	 if(contains3(T1,alltriangles)||contains3(T2,alltriangles)||contains3(T3,alltriangles)||contains3(T4,alltriangles)||contains3(T5,alltriangles)||contains3(T6,alltriangles)) {
		 for(int i =0;i<alltriangles.size();i++) {
			 //System.out.println(2);
			 if(((equal(alltriangles.get(i).point1(),P1))||(equal(alltriangles.get(i).point2(),P1))||(equal(alltriangles.get(i).point3(),P1)))&&(((equal(alltriangles.get(i).point1(),P2)))||(equal(alltriangles.get(i).point2(),P2))||((equal(alltriangles.get(i).point3(),P2))))) {
				 neighbortriangles.add(alltriangles.get(i));//System.out.println(2);
			 }
			 if(((equal(alltriangles.get(i).point1(),P2))||(equal(alltriangles.get(i).point2(),P2))||(equal(alltriangles.get(i).point3(),P2)))&&(((equal(alltriangles.get(i).point1(),P3)))||(equal(alltriangles.get(i).point2(),P3))||((equal(alltriangles.get(i).point3(),P3))))) {
				 neighbortriangles.add(alltriangles.get(i));//System.out.println(2);
			 }
			 if(((equal(alltriangles.get(i).point1(),P1))||(equal(alltriangles.get(i).point2(),P1))||(equal(alltriangles.get(i).point3(),P1)))&&(((equal(alltriangles.get(i).point1(),P3)))||(equal(alltriangles.get(i).point2(),P3))||((equal(alltriangles.get(i).point3(),P3))))) {
				 neighbortriangles.add(alltriangles.get(i));//System.out.println(2);
			 }
		 }
		if(neighbortriangles.size()==0) {
			return null;
		}

		 arraylist<Triangle> sortedneighbors = sorting2( neighbortriangles,P1,P2,P3);
		 return sortedneighbors;
}
	return null;

}
 public Triangle orderedtriangle(arraylist<Triangle> b,Point P1,Point P2,Point P3) {
	 Triangle T1 = new Triangle(P1,P2,P3);
	 Triangle T2 = new Triangle(P1,P3,P2);
	 Triangle T3 = new Triangle(P2,P1,P3);
	 Triangle T4 = new Triangle(P2,P3,P1);
	 Triangle T5 = new Triangle(P3,P2,P1);
	 Triangle T6 = new Triangle(P3,P1,P2);
	 if(contains3(T1,b)) {
		 return T1;
	 }
	 else if(contains3(T2,b)) {
		 return T2;
	 }
	 else if(contains3(T3,b)) {
		 return T3;
	 }
	 else if(contains3(T4,b)) {
		 return T4;
	 }
	 else if(contains3(T5,b)) {
		 return T5;
	 }
	 else if(contains3(T6,b)) {
		 return T6;
	 }
	 else {
		 return null;
	 }
 }
 
public int COUNT_CONNECTED_COMPONENTS(){
	int count=0;
	  for(int k=0;k<alltriangles.size();k++) {
		  if(!((alltriangles.get(k)).marked)) {
			  bfs(alltriangles.get(k));
			  count++;
		  }
	  }
	  for(int h=0;h<alltriangles.size();h++) {
			alltriangles.get(h).marked=false;
		}
	  return count;
	  }
public void bfs(Triangle T) {
	/* Queue<Triangle> gbd = new Queue(alltriangles.size());
	 T.marked2=true;
	 gbd.enqueue(T);
	 arraylist<Triangle> g = getneighbors(T.point1(),T.point2(),T.point3());
	 if(g.size()==0) {
		 return;
	 }
	/* for(int v=0;v<g.size();v++) {
		 g.get(v).marked2=true;
		 gbd.enqueue(g.get(v));
	 }*/
	/* while(!(gbd.isEmpty())) {
		 Triangle t = gbd.dequeue();
		 arraylist<Triangle> b = getneighbors(t.point1(),t.point2(),t.point3());
		 for(int f=0;f<b.size();f++) {
			 if(!(b.get(f).marked2)) {
				 b.get(f).marked2=true;
				 gbd.enqueue(b.get(f));
			 }
		 }
	 }*/
	Queue<Triangle> v = new Queue<Triangle>(alltriangles.size());
	T.marked=true;
	v.enqueue(T);
	while(!v.isEmpty()) {
		Triangle d = v.dequeue();
		arraylist<Triangle> m = getneighbors(d.point1(),d.point2(),d.point3());
		for(int g=0;g<m.size();g++) {
			if(!m.get(g).marked) {
				m.get(g).marked=true;
				v.enqueue(m.get(g));
			}
		}
	}
	
	
}
public PointInterface [] CENTROID (){
	arraylist<Point> centroids = new arraylist<Point>();
	/*for(int i =0;i<alltriangles.size();i++) {
		if(!alltriangles.get(i).marked3) {
			arraylist<Triangle> b = bfs2(alltriangles.get(i));
			arraylist<Point> c = verticeslist(b);
			float xcentroid=0;
			float ycentroid=0;
			float zcentroid=0;
			for(int k =0;k<c.size();k++) {
				int g= c.size();
				System.out.println(g);
				xcentroid= xcentroid+((c.get(k).xcoordinate)/g);
				ycentroid= ycentroid+((c.get(k).ycoordinate)/g);
				zcentroid= zcentroid+((c.get(k).zcoordinate)/g);
			}
			Point p = new Point(xcentroid,ycentroid,zcentroid);
			centroids.add(p);
		}
		System.out.println("*");
	}
		Point[] centroid = new Point[centroids.size()];
		for(int b=0;b<centroids.size();b++) {
			centroid[b]=centroids.get(b);
		}
		
		for(int k=0;k<centroid.length;k++) {
			System.out.println(centroid[k].xcoordinate+","+centroid[k].ycoordinate+","+centroid[k].zcoordinate);
		}
		for(int h=0;h<alltriangles.size();h++) {
			alltriangles.get(h).marked3=false;
		}
		return centroid;*/
	for(int s=0;s<alltriangles.size();s++) {
		if(!alltriangles.get(s).marked) {
			arraylist<Triangle> p = bfs2(alltriangles.get(s));
			//System.out.println(p.size());
			/*for(int k=0;k<p.size();k++) {
				System.out.println(p.get(k).point1().xcoordinate+" "+p.get(k).point1().ycoordinate+" "+p.get(k).point1().zcoordinate+" "+p.get(k).point2().xcoordinate+" "+p.get(k).point2().ycoordinate+" "+p.get(k).point2().zcoordinate+" "+p.get(k).point3().xcoordinate+" "+p.get(k).point3().ycoordinate+" "+p.get(k).point3().zcoordinate);
			}*/
			arraylist<Point> o = verticeslist(p);
			//System.out.println(o.size());
			float x=0;
			float y=0;
			float z=0;
			for(int r=0;r<o.size();r++) {
				x=x+(float)((o.get(r).xcoordinate));
				y=y+(float)((o.get(r).ycoordinate));
				z=z+(float)((o.get(r).zcoordinate));
			}
			float x1 = x/o.size();
			float y1= y/o.size();
			float z1 = z/o.size();
			Point P = new Point(x1,y1,z1);
			centroids.add(P);
		}
	}
	arraylist<Point> cen=sortingc(centroids);
	Point[] c = new Point[centroids.size()];
	for(int i=0;i<cen.size();i++) {
		c[i]=cen.get(i);
	}
	for(int h=0;h<alltriangles.size();h++) {
		alltriangles.get(h).marked=false;
	}
	//System.out.println();
	/*for(int u=0;u<c.length;u++) {
		System.out.print("("+c[u].xcoordinate+","+c[u].ycoordinate+","+c[u].zcoordinate+")");
	}*/
	return c;
}
public arraylist<Triangle> bfs2(Triangle T){
	 /*Queue<Triangle> gbd = new Queue(alltriangles.size());
	 T.marked3=true;
	 arraylist<Triangle> bfs = new <Triangle>arraylist();
	 arraylist<Triangle> added=new <Triangle>arraylist();
	 bfs.add(T);
	 added.add(T);
	 if(getneighbors(T.point1(),T.point2(),T.point3()).size()==0) {
		return bfs;
	 }
	 else {
	 for(int v=0;v<getneighbors(T.point1(),T.point2(),T.point3()).size();v++) {
		 getneighbors(T.point1(),T.point2(),T.point3()).get(v).marked3=true;
		 gbd.enqueue(getneighbors(T.point1(),T.point2(),T.point3()).get(v));
		 added.add(getneighbors(T.point1(),T.point2(),T.point3()).get(v));
	 }
	 while(!(gbd.isEmpty())) {
		 Triangle t = gbd.dequeue();
		 bfs.add(t);
		 arraylist<Triangle> b = getneighbors(t.point1(),t.point2(),t.point3());
		 for(int f=0;f<b.size();f++) {
			 if((!(b.get(f).marked3))) {
				 b.get(f).marked3=true;
				 gbd.enqueue(b.get(f));
			 }
		 }
	 }
	 /*for (int h=0 ; h<bfs.size();h++) {
		 System.out.println(bfs.get(h).point1().xcoordinate+","+bfs.get(h).point1().ycoordinate+","+bfs.get(h).point1().zcoordinate+",,"+bfs.get(h).point2().xcoordinate+","+bfs.get(h).point2().ycoordinate+","+bfs.get(h).point2().zcoordinate+",,"+bfs.get(h).point3().xcoordinate+","+bfs.get(h).point3().ycoordinate+","+bfs.get(h).point3().zcoordinate);	 
	 }
	 return bfs;}*/
	Queue<Triangle> a = new Queue<Triangle>(alltriangles.size());
	arraylist<Triangle> m = new arraylist<Triangle>();
	T.marked=true;
	a.enqueue(T);
	while(!a.isEmpty()) {
		Triangle t = a.dequeue();
		m.add(t);
		arraylist y = getneighbors(t.point1(),t.point2(),t.point3());
		for(int b =0;b<y.size();b++) {
			Triangle h = (Triangle) y.get(b);
			if(!h.marked) {
				h.marked = true;
				a.enqueue(h);
			}
		}
	}
	return m;
}
public arraylist<Point> verticeslist(arraylist<Triangle> b){
	arraylist<Point> vertices = new arraylist<Point>();
     for(int k=0;k<b.size();k++) {
    	 //System.out.println(2);
    	 if (vertices.size()==0)
    		{
    			vertices.add(b.get(0).point1());
    		     vertices.add(b.get(0).point2());
    		     vertices.add(b.get(0).point3());
    		     
    		}
    	 else
    	 {
    	 if(!(cont(vertices,(Point)b.get(k).point1()))) {
    		// System.out.println(2);
    		 vertices.add(b.get(k).point1());
    	 }
    	  if(!cont(vertices,(Point)b.get(k).point2())) {
    		 //System.out.println(3);
    		 vertices.add(b.get(k).point2());
    	 }
    	  if(!cont(vertices,(Point)b.get(k).point3())) {
    		 //System.out.println(4);
    		 vertices.add(b.get(k).point3());
    	 }}
     }
     //System.out.println(vertices.size());
     return vertices;
}
public boolean cont(arraylist<Point> b,Point p) {
	for(int k=0;k<b.size();k++) {
		if(b.get(k).getX()==p.xcoordinate&&b.get(k).getY()==p.ycoordinate&&b.get(k).getZ()==p.zcoordinate) {
			return  true;
		}	
	}
	return false;
}
public boolean contains4(Queue<Triangle> g,Triangle t) {
	for(int h=0;h<g.currentsize;h++) {
		Triangle d = (Triangle) g.array[h];
		if((t.point1().xcoordinate==d.point1().xcoordinate)&&(t.point1().ycoordinate==d.point1().ycoordinate)&&(t.point1().zcoordinate==d.point1().zcoordinate)&&(t.point2().xcoordinate==d.point2().xcoordinate)&&(t.point2().ycoordinate==d.point2().ycoordinate)&&(t.point2().zcoordinate==d.point2().zcoordinate)&&(t.point3().xcoordinate==d.point3().xcoordinate)&&(t.point3().ycoordinate==d.point3().ycoordinate)&&(t.point3().zcoordinate==d.point3().zcoordinate)){
			return true;
		}
		if((t.point1().xcoordinate==d.point1().xcoordinate)&&(t.point1().ycoordinate==d.point1().ycoordinate)&&(t.point1().zcoordinate==d.point1().zcoordinate)&&(t.point2().xcoordinate==d.point3().xcoordinate)&&(t.point2().ycoordinate==d.point3().ycoordinate)&&(t.point2().zcoordinate==d.point3().zcoordinate)&&(t.point3().xcoordinate==d.point2().xcoordinate)&&(t.point3().ycoordinate==d.point2().ycoordinate)&&(t.point3().zcoordinate==d.point2().zcoordinate)){
			return true;
		}
		if((t.point1().xcoordinate==d.point2().xcoordinate)&&(t.point1().ycoordinate==d.point2().ycoordinate)&&(t.point1().zcoordinate==d.point2().zcoordinate)&&(t.point2().xcoordinate==d.point1().xcoordinate)&&(t.point2().ycoordinate==d.point1().ycoordinate)&&(t.point2().zcoordinate==d.point1().zcoordinate)&&(t.point3().xcoordinate==d.point3().xcoordinate)&&(t.point3().ycoordinate==d.point3().ycoordinate)&&(t.point3().zcoordinate==d.point3().zcoordinate)){
			return true;
		}
		if((t.point1().xcoordinate==d.point2().xcoordinate)&&(t.point1().ycoordinate==d.point2().ycoordinate)&&(t.point1().zcoordinate==d.point2().zcoordinate)&&(t.point2().xcoordinate==d.point3().xcoordinate)&&(t.point2().ycoordinate==d.point3().ycoordinate)&&(t.point2().zcoordinate==d.point3().zcoordinate)&&(t.point3().xcoordinate==d.point1().xcoordinate)&&(t.point3().ycoordinate==d.point1().ycoordinate)&&(t.point3().zcoordinate==d.point1().zcoordinate)){
			return true;
		}
		if((t.point1().xcoordinate==d.point3().xcoordinate)&&(t.point1().ycoordinate==d.point3().ycoordinate)&&(t.point1().zcoordinate==d.point3().zcoordinate)&&(t.point2().xcoordinate==d.point2().xcoordinate)&&(t.point2().ycoordinate==d.point2().ycoordinate)&&(t.point2().zcoordinate==d.point2().zcoordinate)&&(t.point3().xcoordinate==d.point1().xcoordinate)&&(t.point3().ycoordinate==d.point1().ycoordinate)&&(t.point3().zcoordinate==d.point1().zcoordinate)){
			return true;
		}
		if((t.point1().xcoordinate==d.point3().xcoordinate)&&(t.point1().ycoordinate==d.point3().ycoordinate)&&(t.point1().zcoordinate==d.point3().zcoordinate)&&(t.point2().xcoordinate==d.point1().xcoordinate)&&(t.point2().ycoordinate==d.point1().ycoordinate)&&(t.point2().zcoordinate==d.point1().zcoordinate)&&(t.point3().xcoordinate==d.point2().xcoordinate)&&(t.point3().ycoordinate==d.point2().ycoordinate)&&(t.point3().zcoordinate==d.point2().zcoordinate)){
			return true;
		}
	}
	return false;
}
 //INPUT [x,y,z]
  public PointInterface CENTROID_OF_COMPONENT (float [] point_coordinates){
	  arraylist<Point> centroids = new arraylist<Point>();
	  Point P = new Point( point_coordinates[0], point_coordinates[1], point_coordinates[2]);
	 for(int i =0;i<alltriangles.size();i++) {
			if(!alltriangles.get(i).marked) {
				arraylist<Triangle> b = bfs2(alltriangles.get(i));
				arraylist<Point> c = verticeslist(b);
				float xcentroid=0;
				float ycentroid=0;
				float zcentroid=0;
				if(contains1(P,c)) {
					for(int k =0;k<c.size();k++) {
						int g= c.size();
						xcentroid= xcentroid+((c.get(k).xcoordinate));
						ycentroid= ycentroid+((c.get(k).ycoordinate));
						zcentroid= zcentroid+((c.get(k).zcoordinate));
					}
					float x1= xcentroid/(c.size());
					float y1= ycentroid/c.size();
					float z1 = zcentroid/c.size();
					Point p = new Point(x1,y1,z1);
					
					centroids.add(p);
				}
			}
	 }
	 Point[] centroid = new Point[centroids.size()];
		for(int b=0;b<centroids.size();b++) {
			centroid[b]=centroids.get(b);
		}
		for(int h=0;h<alltriangles.size();h++) {
			alltriangles.get(h).marked=false;
		}
		
			//System.out.println(centroid[0].xcoordinate+","+centroid[0].ycoordinate+","+centroid[0].zcoordinate);
		
		return centroid[0];
}
  public arraylist<Point> sortingc(arraylist<Point> a){
	  for(int i=0;i<a.size()-1;i++) {
			for(int j =0;j<a.size()-i-1;j++) {
				if((a.get(j).xcoordinate>a.get(j+1).xcoordinate)||((a.get(j).xcoordinate==a.get(j+1).xcoordinate)&&(a.get(j).ycoordinate>a.get(j+1).ycoordinate))||((a.get(j).xcoordinate==a.get(j+1).xcoordinate)&&(a.get(j).ycoordinate==a.get(j+1).ycoordinate)&&(a.get(j).zcoordinate>a.get(j+1).zcoordinate))) {
					Point ch = a.get(j);
					Point ch2 = a.get(j+1);
					a.set(j,ch2);
					a.set(j+1, ch);
				}
			}
		}
	  return a;
	 /* for(int i=1;i<a.size();i++) {
		  for(int j=0;j<i;j++) {
			  if(a.get(j).compareTo(a.get(i))>0) {
				  a.insert(a.get(i));
				  break;
			  }
		  }
	  }*/
  }
 arraylist<arraylist<Point>> bim = new arraylist<arraylist<Point>>();
 public Point[] shortestpoints(arraylist<Point> p1,arraylist<Point> p2){
	 //arraylist<Point> f = new arraylist<Point>();
	 double dis= distance(p1.get(0),p2.get(0));
	 Point a=p1.get(0);
	 Point b = p2.get(0);
	 for(int i=0;i<p1.size();i++) {
		 Point g = p1.get(i);
		 for(int j=0;j<p2.size();j++) {
			 Double d=distance(g,p2.get(j));
			 if(d<dis) {
				 dis=d;
				 a=p1.get(i);
				 b=p2.get(j);
			 }
		 }
		 
	 }
	 Point[] s= new Point[2];
	 s[0]=a;
	 s[1]=b;
	 return s;
	 
 }
 public double sqrt(double n) {
	 double k;
	 if(n==0) {
		 return 0;
	 }
	 double c = n/2;
	 do {
		 k=c;
		 c=(k+(n/k))/2;
	 }
	 while((k-c)!=0);
	 return k;
 }
 public PointInterface [] CLOSEST_COMPONENTS(){
	 arraylist<Point[]> nut= new arraylist<Point[]>();
	 for(int s=0;s<alltriangles.size();s++) {
			if(!alltriangles.get(s).marked) {
				arraylist<Triangle> p = bfs2(alltriangles.get(s));
				/*for(int k=0;k<p.size();k++) {
					System.out.println(p.get(k).point1().xcoordinate+" "+p.get(k).point1().ycoordinate+" "+p.get(k).point1().zcoordinate+" "+p.get(k).point2().xcoordinate+" "+p.get(k).point2().ycoordinate+" "+p.get(k).point2().zcoordinate+" "+p.get(k).point3().xcoordinate+" "+p.get(k).point3().ycoordinate+" "+p.get(k).point3().zcoordinate);
				}*/
				arraylist<Point> o = verticeslist(p);
				//System.out.println(o.size());
				bim.add(o);
			}
	 }
	 for(int i=0;i<bim.size()-1;i++) {
		 for(int j=i+1;j<bim.size();j++) {
			 Point[] d= shortestpoints(bim.get(i),bim.get(j));
			 nut.add(d);
		 }
	 }
	 double distance = distance(nut.get(0)[0],nut.get(0)[1]);
	 int index=0;
	 for(int h=0;h<nut.size();h++) {
		 if(distance(nut.get(h)[0],nut.get(h)[1])<distance) {
			 distance =distance(nut.get(h)[0],nut.get(h)[1]);
			 index=h;
		 }
	 }
	 for(int h=0;h<alltriangles.size();h++) {
			alltriangles.get(h).marked=false;
		}
	// System.out.println(nut.get(index)[0].xcoordinate+" "+nut.get(index)[0].ycoordinate+" "+nut.get(index)[0].zcoordinate+" "+nut.get(index)[1].xcoordinate+" "+nut.get(index)[1].ycoordinate+" "+nut.get(index)[1].zcoordinate);
	 return nut.get(index);
	 }
  public int MAXIMUM_DIAMETER(){
	  arraylist<Triangle> k = maxtrianglescomponent();
	  Triangle []b= corners(k);
	  
	  int d= shortestdistance(b);
	 /* for(int v=0;v<k.size();v++) {
		  for(int i=v+1;i<k.size();i++) {
			  //System.out.println(shortestdistance(k.get(v),k.get(i)));
			  if(shortestdistance(k.get(v),k.get(i))>d) {
				  d=shortestdistance(k.get(v),k.get(i));
			  }
		  }
	  }*/
	  //System.out.println(d);
	  return d;
 }
  public arraylist<Triangle> maxtrianglescomponent(){
	  arraylist<arraylist<Triangle>> gbh = new arraylist<arraylist<Triangle>>();
	  for(int i =0;i<alltriangles.size();i++) {
			if(!alltriangles.get(i).marked) {
				arraylist<Triangle> b = bfs2(alltriangles.get(i));
				gbh.add(b);
			}
	  }
	  arraylist<Triangle> v = gbh.get(0);
	  for(int d=0;d<gbh.size();d++) {
		  if(gbh.get(d).size()>v.size()) {
			  v=gbh.get(d);
		  }
	  }
	  for(int h=0;h<alltriangles.size();h++) {
			alltriangles.get(h).marked=false;
		}
	  //System.out.println(v.size());
	  return v;
  }
  public Triangle[] corners(arraylist<Triangle> v){
	  arraylist<Triangle> req = new arraylist<Triangle>();
	  Triangle t = v.get(0);
	  Queue <Triangle> q= new Queue<Triangle>(alltriangles.size());
	 t.marked=true;
	 q.enqueue(t);
	 Triangle T=t;
	 while(!q.isEmpty()) {
		 T = q.dequeue();
		 arraylist<Triangle> m = getneighbors(T.point1(), T.point2(),T.point3());
		 for(int k=0;k<m.size();k++) {
			 if(!m.get(k).marked) {
				 m.get(k).marked=true;
				 q.enqueue(m.get(k));
			 }
		 }
	 }
	 for(int h=0;h<alltriangles.size();h++) {
			alltriangles.get(h).marked=false;
		}
	 
	 req.add(T);
	 Queue<Triangle> q2 = new Queue<Triangle>(alltriangles.size());
	 T.marked = true;
	 q2.enqueue(T);
	 Triangle T2=T;
	 while(!q2.isEmpty()) {
		 T2 = q2.dequeue();
		 arraylist<Triangle> m = getneighbors(T2.point1(), T2.point2(),T2.point3());
		 //System.out.println(m.size()+"s");
		 for(int k=0;k<m.size();k++) {
			 if(!m.get(k).marked) {
				 m.get(k).marked=true;
				 q2.enqueue(m.get(k));
			 }
		 }
	 }
	 req.add(T2);
	 for(int h=0;h<alltriangles.size();h++) {
			alltriangles.get(h).marked=false;
		}
	 Triangle[] corners = new Triangle[req.size()];
	 for(int i=0;i<req.size();i++) {
		 corners[i]=req.get(i);
	 }
	 return corners;
  }
  public int shortestdistance(Triangle[]b) {
	  Triangle t1= b[0];
	 //System.out.println(b[0].point1().xcoordinate+" "+b[0].point1().ycoordinate+" "+b[0].point1().zcoordinate+" "+b[0].point2().xcoordinate+" "+b[0].point2().ycoordinate+" "+b[0].point2().zcoordinate+" "+b[0].point3().xcoordinate+" "+b[0].point3().ycoordinate+" "+b[0].point3().zcoordinate);
	 // System.out.println(b[1].point1().xcoordinate+" "+b[1].point1().ycoordinate+" "+b[1].point1().zcoordinate+" "+b[1].point2().xcoordinate+" "+b[1].point2().ycoordinate+" "+b[1].point2().zcoordinate+" "+b[1].point3().xcoordinate+" "+b[1].point3().ycoordinate+" "+b[1].point3().zcoordinate);
	  Triangle t2= b[1];
	  Queue<Triangle> bv =new Queue<Triangle>(alltriangles.size());
	  t1.marked=true;
	  bv.enqueue(t1);
	  while(!bv.isEmpty()) {
		  Triangle t = bv.dequeue();
		  if(equaltri(t,t2)) {
			 // System.out.println(2);
			  for(int h=0;h<alltriangles.size();h++) {
					alltriangles.get(h).marked=false;
				}
			  return t.distance;}
		  arraylist<Triangle> m = getneighbors(t.point1(),t.point2(),t.point3());
		  for(int i=0;i<m.size();i++) {
			 // System.out.println(2);
			 /* if(equaltri(t,t2)) {
					 // System.out.println(2);
					  for(int h=0;h<alltriangles.size();h++) {
							alltriangles.get(h).marked=false;
						}
					  return 1 + t.distance;}*/
			  if(!m.get(i).marked) {
				  m.get(i).marked=true;
				  m.get(i).distance=t.distance+1;
				  bv.enqueue(m.get(i));
				  }
				 
			  }
		  }
	  for(int h=0;h<alltriangles.size();h++) {
			alltriangles.get(h).marked=false;
		}
	  return 0;
	  }
  }
  
