public class Triangle implements TriangleInterface {

	Point[] trianglecoordinates;
	int priority;
	Edge[] edges;
	int distance;
	boolean marked;
	boolean marked2;
	boolean marked3;
	public Triangle(Point p1,Point p2,Point p3) {
		this.trianglecoordinates=new Point[] {p1,p2,p3};
		this.priority=0;
		this.edges= new Edge[6];
		this.marked=false;
		this.marked2=false;
		this.marked3= false;
		this.distance=0;
	}
	@Override
	public Point[] triangle_coord() {
		// TODO Auto-generated method stub
		return this.trianglecoordinates;
	}
   public Point point1() {
	   return this.trianglecoordinates[0];
   }
   public Point point2() {
	   return this.trianglecoordinates[1];
   }
   public Point point3() {
	   return this.trianglecoordinates[2];
   }
   public Edge edge1()
   {
	   return edges[0];
   }
   public Edge edge2()
   {
	   return edges[1];
   }
   public Edge edge3()
   {
	   return edges[2];
   }
  public String toString() {
	  return this.point1().toString()+" "+this.point2().toString()+" "+this.point3().toString();
  }
  public void setdistance(Triangle t,int k) {
	  this.distance=k;
  }
}
