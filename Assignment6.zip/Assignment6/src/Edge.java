public class Edge implements EdgeInterface {
	
Point[] edgepoints;
double length;
int priority;

public Edge(Point p1,Point p2) {
	this.edgepoints=new Point[] {p1,p2};
	this.priority=0;
	this.length=distance(p1,p2);
}
	@Override
	public Point[] edgeEndPoints() {
		// TODO Auto-generated method stub
		return this.edgepoints;
	}
    public Point Point1() {
    	return this.edgepoints[0];
    }
    public Point Point2() {
    	return this.edgepoints[1];
    }
    public double length() {
    	return this.length;
    }
    public boolean compareedge(Edge e)
    {
    	if (this.Point1().comparepoint(e.Point1()) && this.Point2().comparepoint(e.Point2()) || 
    			this.Point2().comparepoint(e.Point1()) && this.Point1().comparepoint(e.Point2()))
    	{
    		return true;
    	}
    	return false;
    }
    public double distance(Point p1,Point p2) {
  	  double k = ((p1.xcoordinate-p2.xcoordinate)*(p1.xcoordinate-p2.xcoordinate))+((p1.ycoordinate-p2.ycoordinate)*(p1.ycoordinate-p2.ycoordinate))+((p1.zcoordinate-p2.zcoordinate)*(p1.zcoordinate-p2.zcoordinate));
  	  return sqrt(k);
  	  
    }
    public double sqrt(double n) {
   	 double k;
   	 if(n==0) {
   		 return 0;
   	 }
   	 double c = n/2;
   	 do {
   		 k=c;
   		 c=(k+(n/k))/2;
   	 }
   	 while((k-c)!=0);
   	 return k;
    }
    public String toString() {
    	return this.Point1().toString() +" "+ this.Point2().toString();
    }
}
