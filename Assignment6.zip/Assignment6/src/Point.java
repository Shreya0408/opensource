
public class Point implements PointInterface{
	float xcoordinate;
	float ycoordinate;
	float zcoordinate;
	float[] allcoordinates;
	public Point(float x,float y,float z) {	
		this.xcoordinate=x;
		this.ycoordinate=y;
		this.zcoordinate=z;
		this.allcoordinates=new float[] {x,y,z};		
	}

	@Override
	public float getX() {
		// TODO Auto-generated method stub
		return this.xcoordinate;
	}

	@Override
	public float getY() {
		// TODO Auto-generated method stub
		return this.ycoordinate;
	}

	@Override
	public float getZ() {
		// TODO Auto-generated method stub
		return this.zcoordinate;
	}
	public boolean comparepoint(Point p)
	{
		if (this.getX() == p.getX() && this.getY()==p.getY()&& this.getZ() == p.getZ())
		{
			return true;
		}
		return false;
	}
public String toString() {
	return String.valueOf(this.getX()) +" "+  String.valueOf(this.getY()) + " "+ String.valueOf(this.getZ());
}
	@Override
	public float[] getXYZcoordinate() {
		// TODO Auto-generated method stub
		return this.allcoordinates;
	}
	
	public int compareTo(Point point) {
		if(this.getX()>point.getX())
			return 1;
		else {
			if(this.getX()==point.getX())
			{
				if(this.getY()>point.getY())
					return 1;
				else {
					if(this.getY()==point.getY())
					{
						if(this.getZ()>point.getZ())
							return 1;
						else if(this.getZ()==point.getZ())
							return 0;
						else
							return -1;
					}
					else
						return -1;
				}
			}
			else
				return -1;
		}
	}

}
