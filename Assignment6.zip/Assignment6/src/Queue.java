public class Queue<V>{
	int capacity,currentsize,front,rear;
	Object array[];
public Queue(int capacity) {
	this.capacity=capacity;
	this.array=new Object[capacity];
	this.front=0;
	this.rear=-1;
}
public int size() {
    return currentsize;
    }

    public boolean isEmpty() {
    return currentsize == 0;
    }
	
    public boolean isFull() {
    return currentsize == capacity;
    }

    public void enqueue(V node) {
         if (!isFull()) {
		rear = (rear + 1) % capacity;
		array[rear] = node;
		currentsize++;
         }
    }

    public V dequeue() {
    	V a =(V) array[front];
		if (!isEmpty()) {
        
		front = (front + 1) % capacity;
		currentsize--;
    }
		return a;}
		
		
    
  /*  public static void main(String args[]) {
    	Queue<Integer> li = new Queue(5);
    	System.out.println(li.isEmpty());
    	li.enqueue(2);
    	li.enqueue(34);
    	li.enqueue(89);
    	System.out.println(li.isEmpty());
    	System.out.println(li.currentsize);
    	System.out.println(li.dequeue());
    }*/
}
