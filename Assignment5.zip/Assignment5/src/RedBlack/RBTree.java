package RedBlack;


public class RBTree<T extends Comparable, E> implements RBTreeInterface<T, E>  {
	RedBlackNode root;
	int blackheight;
	public RBTree() {
		this.root=null;
		this.blackheight=0;
	}
    @Override
     public void insert(T key, E value) {
    	if(root==null) {
    		root=new RedBlackNode(value,key);
    		root.colour=true;
    		blackheight=1;
    		return ;
    	}
     RedBlackNode n= new RedBlackNode(value,key);
     RedBlackNode current = root;
     RedBlackNode parent = null;
     RedBlackNode grand = null;
     RedBlackNode uncle=null;
    while (current!=null) {
    	//System.out.println(current.key.compareTo(n.key));
    	 if(current.key.compareTo(n.key)<0) {
    		 //System.out.println(2);
    		 grand=parent;
    		 parent=current;
    		 current=current.right;
    	 }
    	 else if (current.key.compareTo(n.key)>0) {
    		 //System.out.println(1);
    		 grand=parent;
    		 parent=current;
    		 current=current.left;
    	 }
    	 else {
    		//when key which is equal is found 
    		 current.list.add(value); 
    		 return ;
    	 }
     }
    if(parent.key.compareTo(n.key)<0 ) {
    	//System.out.println(2);
    	
		 parent.right=n;
		// System.out.println();
     }
	 else {
		 //System.out.println(1);
		parent.left=n;
		
    }  
       if(grand!=null) {
    	   if(grand.key.compareTo(parent.key)<0)
    	      uncle=grand.left;
    	   else
    		   uncle=grand.right;
       }
       if(parent.getColour()) return;
      rearrange(n,parent,uncle,grand);
     /*
    	   */
    } 
    private RedBlackNode finduncle(RedBlackNode current) {
    	RedBlackNode tmp=findgrand(current);
    	if(tmp==null) {
    		return null;
    	}
    	RedBlackNode tmp1=findparent(current);
    	if(tmp.key.compareTo(tmp1.key)<0) {
    		return tmp.left;
    	}
    	else 
    		return tmp.right;
    }
    private RedBlackNode findgrand(RedBlackNode current) {
    	RedBlackNode tmp=findparent(current);
    	if(tmp==null) {
    		 return null;
    	}
        return findparent(tmp);
    }
    private RedBlackNode findparent(RedBlackNode current) {
    	if(current==root) return null;
    	RedBlackNode tmp=root;
    	RedBlackNode tmpparent=null;
    	while(tmp!=null) {
    		if(tmp.key.compareTo(current.key)==0) {
    			return tmpparent;
    		}
    		else if(tmp.key.compareTo(current.key)<0) {
    			tmpparent=tmp;
    			tmp=tmp.right;
    		}
    		else {
    			tmpparent=tmp;
    			tmp=tmp.left;
    		}
    	}
    	return null;
    }
	public void rearrange(RedBlackNode current,RedBlackNode parent,RedBlackNode uncle,RedBlackNode grand) { 
	    if(parent==null) {
	    	current.colour=true;
	    	blackheight+=1;
	    	return ;
	    }
	    if(grand==null){
	    	if(parent.getColour()) return;
	    }
		if(uncle!=null && !uncle.colour) {
	    	 parent.colour=true;
	    	 uncle.colour=true;
	    	 rearrange(grand,findparent(grand),finduncle(grand),findgrand(grand));
	    	 return ;
	     }
	     else {
	    	 if(grand.key.compareTo(parent.key)>0 && parent.key.compareTo(current.key)>0) {
	    		 RedBlackNode gpp=findparent(grand);
	    		 if(gpp==null) {
	    			 root=rotatewithleftchild(parent,grand);
	    			 root.colour=true;
	    			 root.right.colour=false;
	    		 }
	    		 if(gpp.key.compareTo(grand.key)<0) {
	    			 gpp.right=rotatewithleftchild(parent,grand);
		    		 gpp.right.colour=true;
		    		 gpp.right.right.colour=false; 
	    		 }
	    		 else {
	    		 gpp.left=rotatewithleftchild(parent,grand);
	    		 gpp.left.colour=true;
	    		 gpp.left.right.colour=false;
	    		 }
	    		 return ;
	    		 }
	    	 else if(grand.key.compareTo(parent.key)>0 && parent.key.compareTo(current.key)<0){
	    		 grand.left=rotatewithrightchild(current,parent);
	    		 RedBlackNode gpp=findparent(grand);
	    		 if(gpp==null) {
	    			 root=rotatewithleftchild(parent,grand);
	    			 root.colour=true;
	    			 root.right.colour=false;
	    			 return ;
	    		 }
	    		 if(gpp.key.compareTo(grand.key)<0) {
	    			 gpp.right=rotatewithleftchild(parent,grand);
		    		 gpp.right.colour=true;
		    		 gpp.right.right.colour=false; 
	    		 }
	    		 else {
	    		 gpp.left=rotatewithleftchild(parent,grand);
	    		 gpp.left.colour=true;
	    		 gpp.left.right.colour=false;
	    		 }
	    		 return ;
	    	 }
	    	 else if(grand.key.compareTo(parent.key)<0 && parent.key.compareTo(current.key)<0){
	    		 RedBlackNode gpp=findparent(grand);
	    		 if(gpp==null) {
	    			 root=rotatewithrightchild(parent,grand);
	    			 root.colour=true;
	    			 root.left.colour=false;
	    			 return ;
	    		 }
	    		 if(gpp.key.compareTo(grand.key)<0) {
	    			 gpp.right=rotatewithrightchild(parent,grand);
		    		 gpp.right.colour=true;
		    		 gpp.right.left.colour=false; 
	    		 }
	    		 else {
	    		 gpp.left=rotatewithrightchild(parent,grand);
	    		 gpp.left.colour=true;
	    		 gpp.left.left.colour=false;
	    		 }
	    		 return ;
	    	 }
	    	 else {
	    		 grand.right=rotatewithrightchild(current,parent);
	    		 RedBlackNode gpp=findparent(grand);
	    		 if(gpp==null) {
	    			 root=rotatewithleftchild(parent,grand);
	    			 root.colour=true;
	    			 root.right.colour=false;
	    			 return;
	    		 }
	    		 if(gpp.key.compareTo(grand.key)<0) {
	    			 gpp.right=rotatewithleftchild(parent,grand);
		    		 gpp.right.colour=true;
		    		 gpp.right.right.colour=false; 
	    		 }
	    		 else {
	    		 gpp.left=rotatewithleftchild(parent,grand);
	    		 gpp.left.colour=true;
	    		 gpp.left.right.colour=false;
	    		 }
	    		 return ;	 
	    	 }
	      } 
	     }
	
	public RedBlackNode rotatewithrightchild(RedBlackNode parent,RedBlackNode grand) {
		grand.right=parent.left;
		parent.left=grand;
		return parent;
	}
	public RedBlackNode rotatewithleftchild(RedBlackNode parent,RedBlackNode grand) {
		 grand.left=parent.right;
		 parent.right=grand;
		 return parent;
	}
	
	@Override
    public RedBlackNode<T, E> search(T k) {
		 RedBlackNode current = root;
		 RedBlackNode parent=null;
		 while(current!=null && !current.key.equals(k)) {
			 if(current.key.compareTo(k)<0) {
				 System.out.println(2);
				 parent=current;
				 current=current.right;
				 
			 }
			 else if(current.key.compareTo(k)>0) {
				 System.out.println(1);
				 parent=current;
				 current=current.left;
			 }
		 }
			 if(parent.key.compareTo(k)<0 ) {
			    	//System.out.println(2);
			    	
					return parent.right;
					// System.out.println();
			     }
				 else {
					 //System.out.println(1);
					return parent.left;
					
			    }   
			
		 }
		 //System.out.println(current);
		 
    }
