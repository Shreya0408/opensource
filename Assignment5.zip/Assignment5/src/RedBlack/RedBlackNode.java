package RedBlack;

import Util.RBNodeInterface;

import java.util.List;
import java.util.ArrayList;

public class RedBlackNode<T extends Comparable, E> implements RBNodeInterface<E> {
	RedBlackNode left;
	RedBlackNode right;
	List<E> list=new ArrayList<>();
	E value;
	T key;
	boolean colour;
	public RedBlackNode(E value,T key) {
           this.value=value;
           this.key=key;
           this.left=null;
           this.right=null;
           this.list.add(value);
           this.colour=false;
	}
	public boolean getColour() {
		return this.colour;
	}

    @Override
    public E getValue() {
        return this.value;
    }

    @Override
    public List<E> getValues() {
        return this.list;
    }
}
