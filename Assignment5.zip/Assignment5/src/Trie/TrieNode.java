package Trie;


import Util.NodeInterface;


public class TrieNode<T> implements NodeInterface<T> {
	TrieNode [] charr;
	T value;
	int level;
	public TrieNode() {
		this.charr=new TrieNode[64];
		this.value=null;
		this.level=1;
		
	}

    @Override
    public T getValue() {
        return this.value;
    }


}