package Trie;
import java.util.ArrayList;
public class Trie<T> implements TrieInterface {
public TrieNode<T> root;
public Trie() {
	root= new TrieNode<>();
}
private boolean search1(String name) {
	 TrieNode<T> tmp=root;
	for(int i=0;i<name.length();i++) {
		int index;
   	if(name.charAt(i)>=65 && name.charAt(i)<=90) {
   		index=name.charAt(i)-'A';
   	}
   	else if(name.charAt(i)>=97 && name.charAt(i)<=122){
   		index=name.charAt(i)-'a'+27;
   	}
   	else {
   		if(name.charAt(i)>=48 && name.charAt(i)<=57) {
			index=name.charAt(i)-'0'+54;
		}
   		else if(name.charAt(i)==' ')
   		index=name.charAt(i)+26-' ';
   		else {
   			index=name.charAt(i)+53-'.';	
   		}
   	}
   	if(tmp.charr[index]==null) return false;
      tmp=tmp.charr[index];   	
	}
	//System.out.println(tmp);
   return true;
}
    @Override
    public boolean delete(String word) {
    	//if(root==null) return false;
    	if(!search1(word)) {
    		return false;
    	}
      root=remove(root,word,0);
    	return true;
    }
    private boolean isEmpty(TrieNode node) {
    	//if(node==null) return true;
    	for(int i=0;i<64;i++) {
    		if(node.charr[i]!=null) return false;
     	}
    	if(node.value!=null) return false;
    		return true;
    }
    private TrieNode remove(TrieNode node,String key,int depth){
    	if(depth==key.length()) {
    		node.value=null;
    		if(isEmpty(node)) {
    			return null;
    		}
    		alllenghts.remove(key.length());
    		return node;
    	}
    	int index;
    	if(key.charAt(depth)>=65 && key.charAt(depth)<=90) {
    		index=key.charAt(depth)-'A';
    	}
    	else if(key.charAt(depth)>=97 && key.charAt(depth)<=122){
    		index=key.charAt(depth)-'a'+27;
    	}
    	else {
    		if(key.charAt(depth)>=48 && key.charAt(depth)<=57) {
    			index=key.charAt(depth)-'0'+54;
    		}
    		else if(key.charAt(depth)==' ')
    	   		index=key.charAt(depth)+26-' ';
    	   		else {
    	   			index=key.charAt(depth)+53-'.';	
    	   		}
    	}
       node.charr[index]=remove(node.charr[index],key,depth+1);
    	if(isEmpty(node)) return null;
    	return node;
    }
    @Override
    public TrieNode search(String name) {
    	 TrieNode<T> tmp=root;
    	for(int i=0;i<name.length();i++) {
    		int index;
        	if(name.charAt(i)>=65 && name.charAt(i)<=90) {
        		index=name.charAt(i)-'A';
        	}
        	else if(name.charAt(i)>=97 && name.charAt(i)<=122){
        		index=name.charAt(i)-'a'+27;
        	}
        	else {
        		if(name.charAt(i)>=48 && name.charAt(i)<=57) {
        			index=name.charAt(i)-'0'+54;
        		}
        		else if(name.charAt(i)==' ')
        	   		index=name.charAt(i)+26-' ';
        	   		else {
        	   			index=name.charAt(i)+53-'.';	
        	   		}
        	}
        	if(tmp==null) return null;
        	if(tmp.charr[index]==null) return null;
           tmp=tmp.charr[index];   	
    	}
    	//System.out.println(tmp);
        return tmp;
    }

    @Override
    public TrieNode startsWith(String prefix) {
    	TrieNode<T> tmp=root;
    	for(int i=0;i<prefix.length();i++) {
    		int index;
        	if(prefix.charAt(i)>=65 && prefix.charAt(i)<=90) {
        		index=prefix.charAt(i)-'A';
        	}
        	else if(prefix.charAt(i)>=97 && prefix.charAt(i)<=122){
        		index=prefix.charAt(i)-'a'+27;
        	}
        	else {
        		if(prefix.charAt(i)>=48 && prefix.charAt(i)<=57) {
        			index=prefix.charAt(i)-'0'+54;
        		}
        		else if(prefix.charAt(i)==' ')
        	   		index=prefix.charAt(i)+26-' ';
        	   		else {
        	   			index=prefix.charAt(i)+53-'.';	
        	   		}
        	}
        	if(tmp.charr[index]==null) return null;
        	tmp=tmp.charr[index];
    	}
        return tmp;
    }
    String s ="Di";
    @Override
    
   
    public void printTrie(TrieNode trieNode) {
    	
             if(trieNode.value!=null) {
            	 
               System.out.println("["+"Name:"+" "+((Person)(((TrieNode)trieNode).value)).name+", "+"Phone="+((Person)(((TrieNode)trieNode).value)).phone_number+"]");
               return;
             }
             String g;
            for(int i=0;i<64;i++) {
            	 
            	TrieNode tmp=trieNode.charr[i];
            	if(tmp!=null) {
            		
            		//s=s.concat(getalpha(i));
            		//System.out.println(s);
            		printTrie(tmp);
            		
            	}
            	
            }
            return ;
    }
ArrayList<Integer> alllenghts = new ArrayList<>();
    @Override
    public boolean insert(String name,Object value) {
        TrieNode<T> tmp=root;
        alllenghts.add(name.length());
    	for(int i=0;i<name.length();i++) {
        	int index;
        	if(name.charAt(i)>=65 && name.charAt(i)<=90) {
        		index=name.charAt(i)-'A';
        	}
        	else if(name.charAt(i)>=97 && name.charAt(i)<=122){
        		index=name.charAt(i)-'a'+27;
        	}
        	else {
        		if(name.charAt(i)>=48 && name.charAt(i)<=57) {
        			index=name.charAt(i)-'0'+54;
        		}
        	else if(name.charAt(i)==' ') {
        	   		index=name.charAt(i)+26-' ';}
        	   		else {
        	   			index=name.charAt(i)+53-'.';	
        	   		}
        	}
    		if(tmp.charr[index]==null) {
        		tmp.charr[index]=new TrieNode();
        		tmp.charr[index].level=tmp.level++;
        	}
    		tmp=tmp.charr[index];
        }
    	tmp.value=(T)value;
    	
    	return true; 
    }
    @Override
    public void printLevel(int level) {
        ArrayList<Character> alist=new ArrayList<>();    
    	printlev(root,0,level,alist);   
    	//Collections.sort(alist);
    	sort(alist);
    	System.out.println("Level "+level+":"+prinformat(alist));
    }
    public String prinformat(ArrayList<Character> a) {
    	String s=" ";
    	int i =0;
    	while( i<a.size()) {
    		if((Character.toString(a.get(i))).equals(" ")) {
    			i++;
    		}
    		else {
    			s=s+Character.toString(a.get(i))+",";
    			i++;
    		}
    		
    	}
    	return s.substring(0, s.length()-1);
    }
    private void printlev(TrieNode node,int depth,int level,ArrayList<Character> alist) {
	if(depth==level-1) {
		for(int i=0;i<64;i++) {
			if(node.charr[i]!=null) {
				char ch;
				if(i<26) {
					ch=(char)(i+65);
				}
				else if(i>26&&i<53) {
					ch=(char)(i+70);
				}
				else if(i>25&&i<27) {
				ch=' ';	
				}
				else if(i>53&&i<64) {
					ch=(char)(i-6);
				}
				else {
					ch='.';
				}
		  alist.add(ch);	
			}
		}
	}
	for(int i=0;i<64;i++) {
		if(node.charr[i]!=null) {
			printlev(node.charr[i],depth+1,level,alist);
		}
	}
    }
    @Override
    public void print() {
    	int k=extractm(alllenghts);
        for(int i=1;i<k+2;i++) {
        	//System.out.print("Level"+ ":"+"");
        	printLevel(i);
        }
    }

public String getalpha(int i) {
	char ch;
	if(i<26) {
		ch=(char)(i+65);
	}
	else if(i>26&&i<53) {
		ch=(char)(i+70);
	}
	else if(i>25&&i<27) {
	ch=' ';	
	}
	else if(i>53&&i<64) {
		ch=(char)(i-6);
	}
	else {
		ch='.';
	}
	return Character.toString(ch);
}
private int extractm (ArrayList<Integer> t) {
	for(int i=0;i<t.size()-1;i++) {
		if(t.get(i)>t.get(i+1)) {
			Integer t1 =t.get(i);
			Integer t2=t.get(i+1);
			t.set(i, t2);
			t.set(i+1,t1 );
		}
	}
	int k= t.size();
	return t.get(k-1);
}
public ArrayList<Character> sort(ArrayList<Character> a){
	for(int i=0;i<a.size()-1;i++) {
		for(int j =0;j<a.size()-i-1;j++) {
			if(a.get(j).compareTo(a.get(j+1))>0) {
				Character ch = a.get(j);
				Character ch2 = a.get(j+1);
				a.set(j,ch2);
				a.set(j+1, ch);
			}
		}
	}
	return a;
}
}