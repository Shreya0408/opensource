package ProjectManagement;

import Trie.Trie;

import java.io.*;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import PriorityQueue.MaxHeap;

public class Scheduler_Driver extends Thread implements SchedulerInterface {


    public static void main(String[] args) throws IOException {
//

    	Scheduler_Driver scheduler_driver = new Scheduler_Driver();
        File file;
        if (args.length == 0) {
            URL url = Scheduler_Driver.class.getResource("INP");
            file = new File(url.getPath());
        } else {
            file = new File(args[0]);
        }

        scheduler_driver.execute(file);
    }

    public void execute(File commandFile) throws IOException {


        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader(commandFile));

            String st;
            while ((st = br.readLine()) != null) {
                String[] cmd = st.split(" ");
                if (cmd.length == 0) {
                    System.err.println("Error parsing: " + st);
                    return;
                }
                String project_name, user_name;
                Integer start_time, end_time;

                long qstart_time, qend_time;

                switch (cmd[0]) {
                    case "PROJECT":
                        handle_project(cmd);
                        break;
                    case "JOB":
                        handle_job(cmd);
                        break;
                    case "USER":
                        handle_user(cmd[1]);
                        break;
                    case "QUERY":
                        handle_query(cmd[1]);
                        break;
                    case "": // HANDLE EMPTY LINE
                        handle_empty_line();
                        break;
                    case "ADD":
                        handle_add(cmd);
                        break;
                    //--------- New Queries
                    case "NEW_PROJECT":
                    case "NEW_USER":
                    case "NEW_PROJECTUSER":
                    case "NEW_PRIORITY":
                        timed_report(cmd);
                        break;
                    case "NEW_TOP":
                        qstart_time = System.nanoTime();
                        timed_top_consumer(Integer.parseInt(cmd[1]));
                        qend_time = System.nanoTime();
                        ArrayList<UserReport_> res = timed_top_consumer(Integer.parseInt(cmd[1]));
                       // System.out.println(res);
                        int i=0;
                      /* while(i<res.size()) {
                        	System.out.println(((UserReport)res.get(i)).user()+((UserReport)res.get(i)).budget);
                        	i++;
                        }*/
                        System.out.println("Time elapsed (ns): " + (qend_time - qstart_time));
                        break;
                    case "NEW_FLUSH":
                        qstart_time = System.nanoTime();
                        timed_flush( Integer.parseInt(cmd[1]));
                        qend_time = System.nanoTime();
                        System.out.println("Time elapsed (ns): " + (qend_time - qstart_time));
                        break;
                    default:
                        System.err.println("Unknown command: " + cmd[0]);
                }

            }


            run_to_completion();
            print_stats();

        } catch (FileNotFoundException e) {
            System.err.println("Input file Not found. " + commandFile.getAbsolutePath());
        } catch (NullPointerException ne) {
            ne.printStackTrace();

        }
    }

    @Override
    public ArrayList<JobReport_> timed_report(String[] cmd) {
        long qstart_time, qend_time;
        ArrayList<JobReport_> res = null;
        switch (cmd[0]) {
            case "NEW_PROJECT":
                qstart_time = System.nanoTime();
                res = handle_new_project(cmd);
                qend_time = System.nanoTime();
                for(int i=0;i<res.size();i++) {
                	System.out.println((res.get(i)).project_name()+" "+(res.get(i)).user()+" "+((res.get(i)).job()).name+" "+(res.get(i)).arrival_time());
                }
                //System.out.println(res);
                System.out.println("Time elapsed (ns): " + (qend_time - qstart_time));
                break;
            case "NEW_USER":
                qstart_time = System.nanoTime();
                res = handle_new_user(cmd);
                qend_time = System.nanoTime();
                //System.out.println(userlist);
                //System.out.println(res);
               /* for(int i=0;i<res.size();i++) {
                	System.out.println((res.get(i)).project_name()+" "+(res.get(i)).user()+" "+((res.get(i)).job()).name+" "+(res.get(i)).arrival_time());
                }*/
                //System.out.println(res);
                System.out.println("Time elapsed (ns): " + (qend_time - qstart_time));

                break;
            case "NEW_PROJECTUSER":
                qstart_time = System.nanoTime();
                res = handle_new_projectuser(cmd);
                qend_time = System.nanoTime();
                //System.out.println(res);
              /*for(int i=0;i<res.size();i++) {
                	System.out.println((res.get(i)).project_name()+" "+(res.get(i)).user()+" "+((res.get(i)).job()).name+" "+(res.get(i)).arrival_time()+" "+(res.get(i)).completion_time());
                }*/
                System.out.println("Time elapsed (ns): " + (qend_time - qstart_time));
                break;
            case "NEW_PRIORITY":
                qstart_time = System.nanoTime();
                res = handle_new_priority(cmd[1]);
                //System.out.println(res);
               /* for(int i=0;i<res.size();i++) {
                	System.out.println((res.get(i)).project_name()+" "+(res.get(i)).user()+" "+((res.get(i)).job()).name+" "+(res.get(i)).arrival_time());
                }*/
                qend_time = System.nanoTime();
                System.out.println("Time elapsed (ns): " + (qend_time - qstart_time));
                break;
        }

        return res;
    }

    @Override
    public ArrayList<UserReport_> timed_top_consumer(int top) {
        return sorteduserlist(top,userreportlist);
    }
     public ArrayList<UserReport_> sorteduserlist(int t,ArrayList<UserReport_> b){
    	 ArrayList<UserReport_> reqlist=new ArrayList<>();
    	 if (t>userreportlist.size()) {
    		 return null;
    	 }
    	 for(int i=0;i<b.size()-1;i++) {
    		 for(int j=0;j<(b.size())-i-1;j++) {
    			 if((b.get(j)).getuser().budgetconsumed>(b.get(j+1)).getuser().budgetconsumed) {
    				 UserReport dis = (UserReport) b.get(j);
    				 UserReport dis2 = (UserReport) b.get(j+1);
    				 b.set(j,dis2);
    				 b.set(j+1, dis);
    				 
    			 }
    			 if((b.get(j)).getuser().budgetconsumed==(b.get(j+1)).getuser().budgetconsumed) {
    				 User u1=(b.get(j)).getuser();
        			 User u2 = (b.get(j+1)).getuser();
        			 ArrayList<Job> l1=u1.exjoblist;
        			 ArrayList<Job> l2=u2.exjoblist;
        			 int t1= extractmax2(l1);
        			 int t2=extractmax2(l2);
        			 if(t1>t2) {
        				 UserReport dis = (UserReport) b.get(j);
        				 UserReport dis2 = (UserReport) b.get(j+1);
        				 b.set(j,dis2);
        				 b.set(j+1, dis);
        			 }
    			 }
    			
    		 }
    	 }
    	 for(int i=(b.size())-1;i>(b.size())-t-1;i--) {
    		 reqlist.add(b.get(i));
    	 }
    	 return reqlist;
     }

    @Override
    public void timed_flush(int waittime) {
      ArrayList<Job> g=  mheap.maxheap;
      ArrayList<Job> g1 = new ArrayList<>();
      MaxHeap<Job> m1 = new MaxHeap<>();
     while(g.size()!=0){
    	 Job j =mheap.extractMax();
    	 g1.add(j);
   
     }
     for(int i=0;i<g1.size();i++) {
    	 int wt= globaltime-(g1.get(i)).arrivaltime;
    	 if(wt>=waittime&&((g1.get(i)).project.budget>=(g1.get(i)).runtime)) {
    		 m1.insert((g1.get(i)));
    	 }
    	 else {
    		 mheap.insert((g1.get(i)));
    	 }
     } 
     
    //System.out.println(1);
      implementingflush(m1);
    }
    public void implementingflush(MaxHeap m) {
    	//System.out.println(1);
    	 //System.out.println("---Running code----");
         
    	while(m.maxheap.size()!=0) {
    		//System.out.println("Remaining jobs: "+m.maxheap.size());
    		// System.out.print("Executing:");
             Job j=(Job)m.extractMax();
            // System.out.print(j.name+" "+"from:"+" "+j.project.name);
            // System.out.println();
             int t=j.runtime;
             Project pr=(Project)(trie.search(j.project.name).getValue());
             //Project pr =j.project;
             User us = search1(j.user.name,userlist);
             int B=pr.budget;
             //j.executed=true;
             if(B>=t) {
          	   j.status=true;
          	   pr.budget=B-t;
          	   exjobs.add(j);
          	   globaltime=globaltime+t;
          	  j.executiontime=globaltime;
          	us.exjoblist.add(j);
          	int y = us.budgetconsumed;
          	us.setbudgetconsumed(y+t);
          	JobReport jb = search2(j,alljobreportlist);
          	jb.updateexetime(j);
          	UserReport u =search4(us.name,userreportlist);
          	u.addconsumed(us);
             }
             else {
          	   unexjobs.add(j);
             }
          }
    }
    		
    		
        
    
    private ArrayList<JobReport_> handle_new_project(String[] cmd) {
   	 Project pr=(Project)( trie.search(cmd[1]).getValue());
        if(pr==null) {
       	 System.out.println("No such project exists. "+cmd[2]);
       	 return null ;
        }
        int T1=Integer.parseInt(cmd[2]);
        int T2 = Integer.parseInt(cmd[3]);
      return handlenewproject( pr, T1, T2);
      
       
   }
public ArrayList<JobReport_> handlenewproject(Project pr1,int t1,int t2){
	 ArrayList <JobReport_> reqproreports = new ArrayList<>();
    int i=0;
    while(i<pr1.Jobreportlist.size()) {
   	 if(((pr1.Jobreportlist.get(i)).at)>=t1 &&((pr1.Jobreportlist).get(i)).arrival_time()<=t2) {
   		 reqproreports.add((pr1.Jobreportlist).get(i));
   	 }
    	i++;
    }
    return reqproreports;
}
private ArrayList<JobReport_> handle_new_user(String[] cmd) {
	String t = cmd[1];
	User us =search1(t,userlist);
    if(!list.contains(cmd[1])) {
   	 System.out.println("No such user exists: "+cmd[1]);
   	 return null ;
    }
    int T1=Integer.parseInt(cmd[2]);
    int T2 = Integer.parseInt(cmd[3]);
    return handlenewuser(us,T1,T2);
    
    
}
public ArrayList<JobReport_> handlenewuser(User user,int t1,int t2){
	 ArrayList <JobReport_> requserreports = new ArrayList<>();
	 int i=0;
	
     while(i<user.jobreportlist.size()) {
    	 if(((user.jobreportlist.get(i)).at)>=t1 &&((user.jobreportlist).get(i)).arrival_time()<=t2) {
    		 requserreports.add((user.jobreportlist).get(i));
    	 }
     	i++;
     }
     return requserreports;
}

private ArrayList<JobReport_> handle_new_projectuser(String[] cmd) {
	Project pr=(Project)( trie.search(cmd[1]).getValue());
	 if(pr==null) {
    	 System.out.println("No such project exists. "+cmd[2]);
    	 return null ;
     }
	 String t =cmd[2];
	 User us =search1(t,userlist);
     if(!list.contains(cmd[2])) {
    	 System.out.println("No such user exists: "+cmd[2]);
    	 return null ;
     }
     int T1=Integer.parseInt(cmd[3]);
     int T2 = Integer.parseInt(cmd[4]);
	return handleprojectuser(pr,us,T1,T2);
}
public ArrayList<JobReport_> handleprojectuser(Project pr1, User us,int t1,int t2){
	 ArrayList <JobReport_> prouserreps = new ArrayList<>();
	 ArrayList <JobReport_> prearray = handlenewproject(pr1,t1,t2);
	 int i=0;
	 while(i<prearray.size()) {
		if((( prearray.get(i)).user()).equals(us.name)) {
			prouserreps.add(prearray.get(i));
			
		}
		i++;
	 }
	 return sortedList(prouserreps);
}


    private ArrayList<JobReport_> handle_new_priority(String s) {
        int t= Integer.parseInt(s);
       return  handlenewpriority(t);
    }
    public ArrayList<JobReport_> handlenewpriority(int prio){
    	ArrayList<JobReport_> prioritylist = new ArrayList<>();
    	for(int i=0;i<alljobreportlist.size();i++) {
    		if(!(alljobreportlist.get(i)).JOB.status&&((alljobreportlist.get(i)).JOB.project.priority)>prio) {
    			prioritylist.add((alljobreportlist.get(i)));
    		}
    	}
    	return prioritylist;
    }
 
    public void schedule() {
            execute_a_job();
    }

    public void handle_empty_line() {
       schedule();
    }


    public void handle_query(String key) {
    	System.out.println("Querying");
        System.out.print(key+": ");
        if((jtrie.search(key))==null) {
      	  System.out.print("NO SUCH JOB");
            System.out.println();
            return ;
        }
        if(((Job)jtrie.search(key).getValue()).status) {
      	  System.out.print("COMPLETED");
      	  System.out.println();      
        }
        else {
      	  System.out.print("NOT FINISHED");
      	  System.out.println();
        }

    }
    
    
    
    ArrayList<Job> joblist=new ArrayList<>();
    ArrayList<UserReport_> userreportlist = new ArrayList<>();
    Trie<Job> jtrie=new Trie<>();
    MaxHeap<Job> mheap=new MaxHeap<>(); 
    List<String> list=new ArrayList<>();
    ArrayList<User> userlist=new ArrayList<>();
    
    
    
    
    public void handle_user(String name) {
    	User user=new User(name);
    	UserReport ur =new UserReport(user);
    	list.add(user.name);
    	userlist.add(user);
    	userreportlist.add(ur);
          System.out.println("Creating user");
    }
    
    
    
  ArrayList<JobReport> alljobreportlist =new ArrayList<>();
  
  
    public void handle_job(String[] cmd) {
    	System.out.println("Creating job");    	
        Project pr=(Project)( trie.search(cmd[2]).getValue());
        if(pr==null) {
       	 System.out.println("No such project exists. "+cmd[2]);
       	 return ;
        }
        User us1=new User(cmd[3]);
        if(!list.contains(cmd[3])) {
       	 System.out.println("No such user exists: "+cmd[3]);
       	 return ;
        }
       
        Job job=new Job(cmd[1],pr,us1,Integer.parseInt(cmd[4]));
        User us = search1(job.user.name,userlist);
        joblist.add(job);
        job.subpriority=(joblist.indexOf(job))+1;
        job.arrivaltime=globaltime;
        JobReport jb = new JobReport(job);
        pr.Jobreportlist.add(jb);
        mheap.insert(job);
        jtrie.insert(cmd[1],job);
        us.jobreportlist.add(jb);
        alljobreportlist.add(jb);
    }
    
    
    
    
    Trie<Project> trie=new Trie<>();
    public void handle_project(String[] cmd) {
    	System.out.println("Creating Project");
        Project pro=new Project(cmd[1],Integer.parseInt(cmd[2]),Integer.parseInt(cmd[3]));
        trie.insert(cmd[1], pro);

    }
    
    
    
    
    
    ArrayList<Job> unexjobs=new ArrayList<>();
    ArrayList<Job> exjobs=new ArrayList<>();
    int globaltime=0;
    
    
    
    
   
    
    public void execute_a_job() {
    	 System.out.println("Running code");
         System.out.println("Remaining jobs: "+mheap.maxheap.size());
       while(mheap.maxheap.size()>0) {
         System.out.print("Executing: ");
         Job j=(Job)mheap.extractMax();
         System.out.print(j.name+" "+"from:"+" "+j.project.name);
         System.out.println();
         int t=j.runtime;
         Project pr=(Project)(trie.search(j.project.name).getValue());        
         User us = search1(j.user.name,userlist);
         int B=pr.budget;
         if(B>=t) {
      	   j.status=true;
      	   pr.budget=B-t;
      	   exjobs.add(j);
      	   globaltime=globaltime+t;
      	  j.executiontime=globaltime;
      	us.exjoblist.add(j);
      	int y = us.budgetconsumed;
      	us.setbudgetconsumed(y+t);
      	JobReport jb = search2(j,alljobreportlist);
      	jb.updateexetime(j);
      	UserReport u =search4(us.name,userreportlist);
      	u.addconsumed(us);
         	
      	System.out.println("Project: "+pr.name+ " budget remaining: "+pr.budget);
      	   System.out.println("Execution cycle completed");
      	   break;
         }
         else {
      	   System.out.println("Un-sufficient budget.");
      	   unexjobs.add(j);
         }
      }

    }
    public void handle_add(String[] cmd) {
   	 Project P=(Project) trie.search(cmd[1]).getValue();
        ArrayList<Job> unexjobspro=new ArrayList<>();
        ArrayList<JobReport_> p = new ArrayList<JobReport_>();
        ArrayList<JobReport_> us = new ArrayList<JobReport_>();
        P.budget+=Integer.parseInt(cmd[2]);
        for(int i=0;i<unexjobs.size();i++) {
        	if(unexjobs.get(i).project.equals(P)) {
        		unexjobspro.add(unexjobs.get(i));
        		mheap.insert(unexjobs.get(i));
        		Job j =unexjobs.get(i);
        		User u =search1(j.user.name,userlist);
        	}
        }
        unexjobs.removeAll(unexjobspro);
        
        System.out.println("ADDING Budget");
   }

    public void run_to_completion() {
    	while(mheap.maxheap.size()!=0) {
    		System.out.println("Running code");
            System.out.println("Remaining jobs: "+mheap.maxheap.size());
    		while(mheap.maxheap.size()>0){
            System.out.print("Executing: ");
            Job j=(Job)mheap.extractMax();
            System.out.print(j.name+" "+"from:"+" "+j.project.name);
            System.out.println();
            int t=j.runtime;
            Project pr=(Project)(trie.search(j.project.name).getValue());
            User us = search1(j.user.name,userlist);
            int B=pr.budget;
            if(B>=t) {
         	   j.status=true;
         	   pr.budget=B-t;
         	   exjobs.add(j);
         	   globaltime=globaltime+t;
         	  j.executiontime=globaltime;
         	us.exjoblist.add(j);
         	
         	int y = us.budgetconsumed;
          	us.setbudgetconsumed(y+t);
          	JobReport jb = search2(j,alljobreportlist);
          	jb.updateexetime(j);
          	UserReport u =search4(us.name,userreportlist);
          	u.addconsumed(us);
          	System.out.println("Project: "+pr.name+ " budget remaining: "+pr.budget);
         	   System.out.println("System execution completed");
         	   break;
            }
            else {
         	   System.out.println("Un-sufficient budget.");
         	   unexjobs.add(j);
            }
         }
    	}
    		
    	}

    

    public void print_stats() {
    	System.out.println("--------------STATS---------------");
    	System.out.println("Total jobs done: "+exjobs.size());
    	for(int i=0;i<exjobs.size();i++) {
    		System.out.println("Job{user=�"+(exjobs.get(i)).user.name+"�, project=�"+(exjobs.get(i)).project.name+"�, jobstatus=COMPLETED, execution_time="+(exjobs.get(i)).runtime+", end_time="+(exjobs.get(i)).executiontime+", name=�"+(exjobs.get(i)).name+"�}");
    	}
    	System.out.println("------------------------");
    	System.out.println("Unfinished jobs: ");
    	int i=0;
    	while(i<unexjobs.size()&&unexjobs.get(i)!=null) {
    		System.out.println("Job{user=�"+(unexjobs.get(i)).user.name+"�, project=�"+(unexjobs.get(i)).project.name+"�, jobstatus=REQUESTED, execution_time="+(unexjobs.get(i)).runtime+", end_time=null"+", name=�"+(unexjobs.get(i)).name+"�}");
    		i++;
    	}
    	System.out.println("Total unfinished jobs: "+unexjobs.size());
    	System.out.println("--------------STATS DONE---------------");
    }
    public User search1(String  username,ArrayList<User>searchlist){
    	int i=0;
    	while(i<searchlist.size()) {
    		if(searchlist.get(i).name.equals(username)) {
    			return searchlist.get(i);
    			
    		}
    		i++;
    	}
    	return null;
    }
    public JobReport search2(Job j, ArrayList<JobReport> jobreportlist) {
    	for (int i=0;i<jobreportlist.size();i++) {
    		if(((jobreportlist.get(i).job()).name).equals(j.name)) {
    			return jobreportlist.get(i);
    		}
    	}
    	return null;
    }
    public ArrayList<JobReport_> search3(int p , ArrayList<JobReport_> b) {
   	 ArrayList<JobReport_> arr = new ArrayList<>();
       	int i= 0;
       	//System.out.println(2);
       	while(i< b.size()) {
       		if(((b.get(i)).pro()).priority>p && !(b.get(i).job().status)) {
       			arr.add(b.get(i));
       			i++;
       			
       		}
       		i++;
       	}
       	return arr;
       }

    public UserReport search4(String uname,ArrayList<UserReport_> u) {
    	int i=0;
    	while (i<u.size()) {
    		if((u.get(i)).user().equals(uname)) {
    			return (UserReport) u.get(i);
    		}
    		i++;
    	}
    	return null;
    } 
    
    public int search5(Job j,ArrayList<Job> jb) {
    	int i=0;
    	while(i<jb.size()) {
    		if((j.name).equals((jb.get(i)).name)){
    			return i;
    		}
    	}
    	return -1;
    }
    public int extractmax2(ArrayList<Job> a) {
    	for (int i=0;i<a.size()-1;i++) {
    		if(a.get(i).executiontime>a.get(i+1).executiontime) {
    			Job j1=a.get(i);
    			Job j2 = a.get(i+1);
    			a.set(i, j2);
    			a.set(i+1, j1);
    		}
    	}
    	int k = a.size();
    	return (a.get(k-1)).executiontime;
    }
public ArrayList<JobReport_> sortedList(ArrayList<JobReport_> a){
	 for(int i=0;i<a.size()-1;i++) {
		 for(int j=0;j<(a.size())-i-1;j++){
			 JobReport jb1 = (JobReport) a.get(i);
			 JobReport jb2 = (JobReport) a.get(i+1);
			 if(!(jb1.JOB.status)&& jb2.JOB.status) {
				 a.set(i, jb2);
				 a.set(i+1,jb1);
				 
			 }
			 else if(jb1.JOB.status && jb2.JOB.status ) {
				 if(jb1.JOB.executiontime>jb2.JOB.executiontime){
					 a.set(i, jb2);
					 a.set(i+1,jb1);
				 }
			 }
			 else if(!(jb1.JOB.status)&&!(jb2.JOB.status)) {
				 if(jb1.JOB.subpriority>jb2.JOB.subpriority) {
					 a.set(i, jb2);
					 a.set(i+1,jb1);
				 }
			 }
		 }
		 }
	 return a;
}



}

