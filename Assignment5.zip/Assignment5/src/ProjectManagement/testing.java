package ProjectManagement;
import java.util.*;
public class testing {
	public static void main(String[] args) {
        Map<Integer,List<Character>> map=new HashMap<>();
        List<Character> list=new ArrayList<>();
        list.add('a');
        list.add('b');
        list.add('c');
        map.put(2, list);
        list=new ArrayList<>();
        list.add('d');
        list.add('e');
        list.add('f');
        map.put(3,list);
        Character[] arr= {'g','h','i'};
        map.put(4,Arrays.asList(arr));
        System.out.println((map.get(4)).toString());
	}
}
