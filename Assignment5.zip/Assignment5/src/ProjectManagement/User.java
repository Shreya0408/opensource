package ProjectManagement;
import java.util.ArrayList;
public class User implements Comparable<User> {
	String name;
	ArrayList<Job> exjoblist;
	ArrayList<JobReport> jobreportlist;
	int budgetconsumed;
    public User(String n) {
    	this.name=n;
    	this.exjoblist =new ArrayList<>();
    	this.jobreportlist=new ArrayList<>();
    	this.budgetconsumed=0;
    }
	@Override
    public int compareTo(User user) {
        return (this.name).compareTo(user.name);
    }
	public void setbudgetconsumed(int b) {
		this.budgetconsumed=b;
	}
}
