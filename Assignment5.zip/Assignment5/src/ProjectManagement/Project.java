package ProjectManagement;
import java.util.ArrayList;

public class Project {
     String name;
     int priority;
     int budget;
     ArrayList<Job> jobslist ;
     ArrayList<JobReport> Jobreportlist;
     public Project(String name,int p,int b) {
    	 this.name=name;
    	 this.budget=b;
    	 this.priority=p;
    	 this.jobslist=new ArrayList<>();
    	 this.Jobreportlist= new ArrayList<>();
     }
}
