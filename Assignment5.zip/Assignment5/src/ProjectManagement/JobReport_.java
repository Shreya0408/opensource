package ProjectManagement;

public interface JobReport_ {
	default String user() {
		return null;
	} 
	   default String project_name() {
		return null;
	}  
	   default int budget() {
		return 0;
	} 
	   default int arrival_time() {
		return 0;
	}  
	   default int completion_time() {
		return 0;
	} 
	   default Job job() {
		   return null;
	   }
	   default Project pro() {
		   return null;
	   }
default void updateexetime(Job job) {
	
}
}
