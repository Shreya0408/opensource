package ProjectManagement;

public class Job implements Comparable<Job> {
    String name;
    Project project;
    User user;
    int runtime;
    boolean status;
    boolean executed ;
    int subpriority;
    int executiontime;
    int arrivaltime;
    JobReport_ jbr;
    public Job(String n,Project p,User u,int rt) {
    	this.name=n;
    	this.project=p;
    	this.user=u;
    	this.runtime=rt;
    	this.status=false;
    	this.executed=false;
    	this.subpriority=0;
    	this.executiontime=0;
    	this.arrivaltime=0;
    }
    @Override
    public int compareTo(Job job) {
        if((this.project.priority)>(job.project.priority))
        	return 1;
        else if((this.project.priority)<(job.project.priority)) {
        	return -1;
        }
        else if((this.project.priority)==(job.project.priority)&&(this.subpriority)<(job.subpriority)){
        	return 1;
        }
        else if((this.project.priority)==(job.project.priority)&&(this.subpriority)>(job.subpriority)) {
        	return -1;
        }
        else {
        	return 0;
        }
    }
    public void setsubprio(int g) {
    	this.subpriority=g;
    }
    public int getarrtime() {
    	return this.arrivaltime;
    }
}