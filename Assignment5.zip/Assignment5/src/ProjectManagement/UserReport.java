package ProjectManagement;

public class UserReport implements UserReport_ {
	String username;
	int budget;
	User user;
	public UserReport(User u) {
		this.username=u.name;
		this.budget= u.budgetconsumed;
		this.user=u;
	}
	 public String user()    {
		 return this.username; 
		 }
	   public int consumed() {
		   return this.budget;
		   }
	   public void addconsumed(User u) {
		   this.budget=u.budgetconsumed;
	   }
	   public User getuser() {
		  return this.user;
	   }
}
