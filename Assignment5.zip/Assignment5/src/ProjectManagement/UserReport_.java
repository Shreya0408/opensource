package ProjectManagement;

public interface UserReport_ {
	 default String user()     { return null; }
	   default int consumed() { return 0; }
      default  void setconsumed(User u) {}
      default User getuser() {
    	  return null;
      }
}
