package ProjectManagement;

public class JobReport implements JobReport_ {
	String username;
	String projectname;
	int budget2;
	int at;
	Job JOB;
	int completiontime;
	public JobReport(Job job ) {
		this.username=job.user.name;
		this.projectname=job.project.name;
		this.budget2=job.project.budget;
		this.at= job.arrivaltime;
		this.JOB=job;
		this.completiontime= job.executiontime;
		
	}
	public String user() {
		return this.username;
		
	}
	public String project_name() {
		return this.projectname;
	}
	public int budget() {
		return this.budget2;
	}
	public int arrival_time() {
		 return this.at;
	 }
	public int completion_time() {
		return this.completiontime;
	}
	public Job job() {
		return this.JOB;
	}
	public Project pro() {
		return this.JOB.project;
	}
	public void updateexetime(Job job) {
		this.completiontime=job.executiontime;
	}
}
