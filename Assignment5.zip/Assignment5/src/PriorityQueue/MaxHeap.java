package PriorityQueue;

import java.util.ArrayList;


public class MaxHeap<T extends Comparable> implements PriorityQueueInterface<T> {
	public ArrayList<T> maxheap ;
    public MaxHeap() {
    	 maxheap = new ArrayList<T>();
    }
    int current;
    private boolean islastnode(int current) {
    	if(maxheap.size()==1) {
    		return true;
    	}
    	if (maxheap.size()==2&&current==1) {
    		return true;
    	}
    	if(maxheap.size()==2&&current==0) {
    		return false;
    	}
    		
    	if(current>=(((maxheap.size())-1)/2) && current<=(maxheap.size()-1)) {
    		return true;
    	}
    	return false;
    }
    @Override
    public void insert(T element) {
    	maxheap.add(element);
    	upshifting(element,maxheap.size()-1);  	   	
    }
    private void upshifting(T ele,int k) {
    	if(k==0) {
    		return;
    	}
    	T par = maxheap.get((k-1)/2);
    	if(par.compareTo(ele)<0) {
    		maxheap.set(k, par);
    		maxheap.set((k-1)/2, ele);
    		upshifting(maxheap.get((k-1)/2),(k-1)/2);
    	}
    	
    }
    @Override
    public T extractMax() {
    	if(maxheap.isEmpty()) return null;
    	if(maxheap.size()==1) {
    		T max=maxheap.remove(0);
    		return max; 
    	}
    	T maximum=maxheap.get(0);
        maxheap.set(0,maxheap.get(maxheap.size()-1));
        maxheap.remove((maxheap.size())-1);
        downshifting(maxheap.get(0),0);
       return maximum;
    }
private void downshifting(T ele,int k) {
	if(islastnode(k)) {
		//System.out.println(1);
		return;
	}
	else {
		if(maxheap.size()==2*k+2) {
			//System.out.println(4);
			if(maxheap.get(k).compareTo(maxheap.get(2*k+1))<0) {
			T node=ele;
			maxheap.set(k, maxheap.get((2*k)+1));
			maxheap.set((2*k)+1, node);
			downshifting(maxheap.get((2*k)+1),(2*k)+1);
			return;
			}
			else {
				return;
			}
		}
	if(maxheap.get(2*k+2).compareTo(maxheap.get(2*k+1))>0) {
		//System.out.println(2);
		T node=maxheap.get(k);
		maxheap.set(k, maxheap.get((2*k)+2));
		maxheap.set((2*k)+2, node);
		downshifting(maxheap.get((2*k)+2),(2*k)+2);
		return;
	}
		
	else {
		//System.out.println(3);
		T node=ele;
		maxheap.set(k, maxheap.get((2*k)+1));
		maxheap.set((2*k)+1, node);
		downshifting(maxheap.get((2*k)+1),(2*k)+1);
	}
	}
}
public void remove(T ele,int k) {
	maxheap.set(k,maxheap.get(maxheap.size()-1));
	 maxheap.remove(maxheap.size()-1);
	 downshifting(maxheap.get(k),k);
	 System.out.println(1);
}
}