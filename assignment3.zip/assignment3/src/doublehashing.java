public class doublehashing implements MyHashTable_<pair, Student> {
	hashfunctions function=new hashfunctions();
	int currentsize;
	Student[] hashtable ;
	int T=1;
	public doublehashing(int size) {
		 this.T=size;
	     hashtable = new Student[T];
		currentsize=0;
	}
	
	 public int insert(pair key, Student obj) {
		 String a = key.fname+key.lname;
		 int k=0;
		 long index = function.h1(a,T);
		 if(hashtable[(int)index]==null) {
			 hashtable[(int)index]=obj;
			 ++currentsize;
			 return 1;
		 }
		 else {
			 long index2 = function.h2(a, T);
			 k=1;
			 while(hashtable[(int) (((int)function.h1(a, T)+k*function.h2(a, T))%T)]!=null) {
				 				 k++;
				 }
			 hashtable[(int) (((int)function.h1(a, T)+k*function.h2(a, T))%T)] =obj;
			 k++;
			 ++currentsize;
		 }
		 return k;
	 }
	
	   // Update object for given key 
	   public int update(pair key, Student obj) {
		   String a = key.fname+key.lname;
		   long index = function.h1(a,T);
			  long index2 = function.h2(a, T);
			  int k=0;
			  while(k<currentsize) {
				  if(hashtable[(int)(((int)function.h1(a, T)+(k*function.h2(a, T)))%T)]!=null) {
					 long newindex= (function.h1(a, T)+k*function.h2(a, T))%T;
					 if(key.fname.equals(hashtable[(int)newindex].fname)&&key.lname.equals(hashtable[(int)newindex].lname )) {
						 //System.out.println(hashtable[(int)newindex].fname);
						 hashtable[(int)newindex]=obj;
						 return k+1;
					 }
				  }
				  k++;
			  }   
		   return -1;
	   }
	 
	   // Delete object for given key 
	   public int delete(pair key) {
		   String a = key.fname+key.lname;
		   long index = function.h1(a,T);
			  long index2 = function.h2(a, T);
			  int k=0;
			  while(k<currentsize) {
				  if(hashtable[(int)(((int)function.h1(a, T)+(k*function.h2(a, T)))%T)]!=null) {
					 long newindex= (function.h1(a, T)+k*function.h2(a, T))%T;
					 if(key.fname.equals(hashtable[(int)newindex].fname)&&key.lname.equals(hashtable[(int)newindex].lname )) {
						 //System.out.println(hashtable[(int)newindex].fname);
						 hashtable[(int)newindex]=null;
						 return k+1;
					 }
				  }
				  k++;
			  }   
		   return -1;
		   
	   }
	 
	   // Does an object with this key exist? 
	   public boolean contains(pair key) {
			  String a = key.fname+key.lname;
			  long index = function.h1(a,T);
			  long index2 = function.h2(a, T);
			  int k=0;
			  while(k<currentsize) {
				  if(hashtable[(int)(((int)function.h1(a, T)+(k*function.h2(a, T)))%T)]!=null) {
					 long newindex= (function.h1(a, T)+k*function.h2(a, T))%T;
					 if(key.fname.equals(hashtable[(int)newindex].fname)&&key.lname.equals(hashtable[(int)newindex].lname )) {
						 //System.out.println(hashtable[(int)newindex].fname);
						 return true;
					 }
				  }
				  k++;
			  }   
		   return false;   
	   } 
	 
	   // Return the object with given key 
	   public Student get(pair key) throws NotFoundException{
		   try {
				  String a = key.fname+key.lname;
				  long index = function.h1(a,T);
				  long index2 = function.h2(a, T);
				  int k=0;
				  while( k<=currentsize) {
					  if(hashtable[(int)(((int)function.h1(a, T)+(k*function.h2(a, T)))%T)]!=null) {
						 long newindex= (function.h1(a, T)+k*function.h2(a, T))%T;
						 if(key.fname.equals(hashtable[(int)newindex].fname)&&key.lname.equals(hashtable[(int)newindex].lname )) {
							 return hashtable[(int)newindex];
						 }
					  }
					  k++;
				  }   
			   return null;   
		   }
		   catch(Exception e) { 
			   return null;
		   }
	   }
	 
	   // �Address� of object with given key (explained below) 
	   public String address(pair key) throws NotFoundException{
		  try {
			  String a = key.fname+key.lname;
			  long index = function.h1(a,T);
			  long index2 = function.h2(a, T);
			  int k=0;
			  while(k<=currentsize) {
				  if(hashtable[(int)(((int)function.h1(a, T)+(k*function.h2(a, T)))%T)]!=null) {
					 long newindex= (function.h1(a, T)+k*function.h2(a, T))%T;
					 if(key.fname.equals(hashtable[(int)newindex].fname)&&key.lname.equals(hashtable[(int)newindex].lname )) {
						 return ""+newindex;
					 }
					}
				  
				  k++;
			  }
			  return "E";
		  }
		  catch(NullPointerException e){
			return "E" ;
		  }
	   }
	  
	   }

