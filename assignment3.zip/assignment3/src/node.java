public class node {
	Student data;
	node left;
	node right;
	pair data2;
	public node(Student data,pair data2) {
		this.data = data;
		this.data2= data2;
		left = null;
		right = null;
	}
	

}
