public class bst {
	public node root;
	public bst(node root) {
		this.root=root;
	}
	public boolean search(pair my){
		node current = root;
		while(current!=null){
			if(current.data.fname.equals(my.fname) && current.data.lname.equals(my.lname)){
				return true;
			}else if(current.data.fname.compareTo(my.fname)>0){
				current = current.left;
			}else{
				current = current.right;
			}
		}
		return false;
	}

public int insert(node my){
	int k=1;	
	node current = root;
	node parent = null;
	while(current!=null){
		parent = current;
		if(current.data.fname.compareTo(my.data.fname)>0){				
			current = current.left;
			}
		else{
			current = current.right;
			}
          k++;
		}
	if(parent.data.fname.compareTo(my.data.fname)>0) {
		parent.left = my;
	}
	else {
		parent.right=my;	
	}       
       return k;
	}

public int update(node my) {
	int k=1;	
	node current = root;
	node parent = current;
	if(root!=null) {
	while(current!=null&&(!current.data.fname.equals(my.data.fname) || !current.data.lname.equals(my.data.lname))){
		parent = current;
		if(current.data.fname.compareTo(my.data.fname)>0){				
			current = current.left;
			}
		else {
			current = current.right;
			}
          k++;
		}
	if(parent.data.fname.compareTo(my.data.fname)>0) {
		current = my;
		return k;
	}
	else if(parent.data.fname.compareTo(my.data.fname)<=0)  {
	current=my;
	return k;
	}
	}
       return -1;
	
	
}
public Student get(pair key){
	node current = root;
	node parent = null;
	while(!current.data.fname.equals(key.fname)|| !current.data.lname.equals(key.lname)) {
		parent = current;
		if(current.data.fname.compareTo(key.fname)>0) {
			current = current.left;
		}
		else {
			current=current.right;
		}	
	}
	return current.data;
}
public int delete(pair key) {
	int k=1;
	node parent=null;
	node current=root;
	if(root!=null) {
	while(current!=null&&(!current.data.fname.equals(key.fname)|| !current.data.lname.equals(key.lname))) {
		parent = current;
		if(current.data.fname.compareTo(key.fname)>0) {
			current = current.left;
		}
		else {
			current=current.right;
		}
		 k++;
	}
	if(current!=null&&current.left==null && current.right==null){
		if(current==root){
			root = null;
			return 1;
		}
		if(parent.data.fname.compareTo(key.fname)>0){
			parent.left = null;
		}
		else{
			parent.right = null;
		}
		return k;
	}
	else if(current!=null&&current.right==null){
		if(current==root){
			root = current.left;
			return k+1;
		}
		else if(parent.data.fname.compareTo(key.fname)>0){
			parent.left = current.left;
		}
		else{
			parent.right = current.left;
		}
		return k+1;
	}
	else if(current!=null&&current.left==null){
		if(current==root){
			root = current.right;
			return k+1;
		}
		else {
			if(current.data.fname.compareTo(key.fname)>0){
			parent.left = current.right;
		}
		else{
			parent.right = current.right;
		}
	}
		return k+1;
	}
	else if(current!=null&&current.left!=null && current.right!=null){		
		node successor	 = getSuccessor(current);
		if(current==root){
			root = successor;
		}
		else {
			if(parent.data.fname.compareTo(key.fname)>0){
			parent.left = successor;
		}
		else{
			parent.right = successor;
		}
		}
		successor.left = current.left;
		return k+nocount(current);
	}		
	}
		return -1;
}
public int nocount(node current) {
	int count=0;
	while(current!=null){
		current = current.left;
	    count++;
	}
	return count;
}
public node getSuccessor(node deletenode){
	node successsor =null;
	node successsorParent =null;
	node current = deletenode.right;
	while(current!=null){
		successsorParent = successsor;
		successsor = current;
		current = current.left;
	}
	if(successsor!=deletenode.right){
		successsorParent.left = successsor.right;
		successsor.right = deletenode.right;
	}
	return successsor;
}
public String address(pair key) {
		node current = root;
		node parent = null;
		String k="";
		while(!current.data.fname.equals(key.fname)||!current.data.lname.equals(key.lname)) {
			parent = current;
			if(current.data.fname.compareTo(key.fname)>0) {
				current = current.left;
				k= k+"L";
			}
			else {
				current=current.right;
				k=k+"R";
			}	
		}
		return k;	
}
}

