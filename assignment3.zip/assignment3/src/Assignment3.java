import java.io.BufferedReader;
	import java.io.FileReader;
	import java.io.IOException;
	import java.io.InputStreamReader;

	public class Assignment3 {
		
		public static void main(String[] args) throws IOException, NotFoundException {    
			int N=Integer.parseInt(args[0]); 
			BufferedReader br=new BufferedReader(new FileReader(args[2]));
		    
			if(args[1].equals("DH")) {
				doublehashing checker=new doublehashing(N);
				String name;
			     hashfunctions function=new hashfunctions();
				 while((name=br.readLine())!=null) {
					// System.out.println(name);
		    		 String[] str=name.split(" ");
		    		 
		    		 pair k = new pair(str[1],str[2]);
		    		 //System.out.println(function.h1(k.fname+k.lname,3));
		    		 //System.out.println(function.h2(k.fname+k.lname,5));
		    		
					if(str[0].equals("insert")) {
						Student st = new Student(str[1],str[2],str[3],str[4],str[5]);
		    			 System.out.println(checker.insert(k,st));
		    		 }
		    		if(str[0].equals("update")) {
		    			Student st = new Student(str[1],str[2],str[3],str[4],str[5]);
		    			System.out.println(checker.update(k, st));
		    		}
		    		if(str[0].equals("delete")) {
		   			 System.out.println(checker.delete(k));
		   		 }
		    		if(str[0].equals("contains")) {
		   			 System.out.println(checker.contains(k)? "T":"F");
		   		 }
		    		if(str[0].equals("get")) {
		   			Student st1=(Student)checker.get(k);
		    			if(st1!=null) {
		   				System.out.println(st1.fname+" "+st1.lname+" "+st1.hostel+" "+st1.department+" "+st1.cgpa());
		   			}
		   			else {
		   				System.out.println("E");
		   			}
		   		 } 
		    		if(str[0].equals("address")) {
		   			 System.out.println(checker.address(k));
		   		 }
		    		//System.out.println(checker.hashtable[1]);
		    	 }
		    }
		    else if(args[1].equals("SCBST")) {
		       scbst checker = new scbst(N);
		       String name;
			     hashfunctions function=new hashfunctions();
				 while((name=br.readLine())!=null) {
					// System.out.println(name);
		    		 String[] str=name.split(" ");
		    		 
		    		 pair k = new pair(str[1],str[2]);
		    		 //System.out.println(function.h1(k.fname+k.lname,5));
		    		 //System.out.println(function.h2(k.fname+k.lname,5));
		    		
					if(str[0].equals("insert")) {
						Student st = new Student(str[1],str[2],str[3],str[4],str[5]);
		    			 System.out.println(checker.insert(k,st));
		    		 }
		    		if(str[0].equals("update")) {
		    			Student st = new Student(str[1],str[2],str[3],str[4],str[5]);
		    			System.out.println(checker.update(k, st));
		    		}
		    		if(str[0].equals("delete")) {
		   			 System.out.println(checker.delete(k));
		   		 }
		    		if(str[0].equals("contains")) {
		   			 System.out.println(checker.contains(k)? "T":"F");
		   		 }
		    		if(str[0].equals("get")) {
		   			Student st1=(Student)checker.get(k);
		    			if(st1!=null) {
		   				System.out.println(st1.fname+" "+st1.lname+" "+st1.hostel+" "+st1.department+" "+st1.cgpa());
		   			}
		   			else {
		   				System.out.println("E");
		   			}
		   		 } 
		    		if(str[0].equals("address")) {
		   			 System.out.println(checker.address(k));
		   		 }
		    		//System.out.println(checker.hashtable[1]);
		    	 }
		    }
			
	}
	}



