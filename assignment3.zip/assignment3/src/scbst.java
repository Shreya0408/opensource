public class scbst implements MyHashTable_<pair, Student>{
	hashfunctions function=new hashfunctions();
	bst[] bsttable ;
	int N=1;
	public scbst(int N) {
		this.N=N;
		bsttable = new bst[N];
	}	    
    public int insert(pair key, Student obj) {
    	 String a = key.fname+key.lname;
    	 long index = function.h1(a,N);
    	 node n = new node(obj,key);
		 if(bsttable[(int)index]==null) {
			 bsttable[(int)index]=new bst(n);
			 return 1;
		 }
			return bsttable[(int)index].insert(n);
		   }
		 
		   // Update object for given key 
  public int update(pair key, Student obj) {
		 String a = key.fname+key.lname;
		  long index = function.h1(a,N);
          node n = new node(obj,key);
     if(bsttable[(int)index].root!=null&&bsttable[(int)index].root.data.fname.equals(key.fname) &&bsttable[(int)index].root.data.lname.equals(key.lname)) {
		    		 bsttable[(int)index].root = n;
		    	 }
		     	 return bsttable[(int)index].update(n);  
		   }
		 
		   // Delete object for given key 
		   public int delete(pair key) {
			   String a = key.fname+key.lname;
				  long index = function.h1(a,N);
				  return  bsttable[(int)index].delete(key);
		   }
		 
		   // Does an object with this key exist? 
		   public boolean contains(pair key) {
			   String a = key.fname+key.lname;
				  long index = function.h1(a,N);
				return  bsttable[(int)index].search(key); 
		   }
		 
		   // Return the object with given key 
		   public Student get(pair key) throws NotFoundException{
			   try {
			   String a = key.fname+key.lname;
				  long index = function.h1(a,N);
 if(bsttable[(int)index].root.data.fname.equals(key.fname)&&bsttable[(int)index].root.data.lname.equals(key.lname)) {
					  return bsttable[(int)index].root.data; 
				  }
			   return bsttable[(int)index].get(key);
		   }
			   catch(NullPointerException e) {
				   return null;
			   }
		   }
		 
		   // �Address� of object with given key (explained below) 
  public String address(pair key) throws NotFoundException{
			   try{
				if(contains(key)) {
					 String a = key.fname+key.lname;
					  long index = function.h1(a,N);
	if(bsttable[(int)index].root.data.fname.equals(key.fname)&&bsttable[(int)index].root.data.lname.equals(key.lname)) {
						  return index+"-"; 
					  }
	             return index+"-"+bsttable[(int)index].address(key);
				}
			  return "E";
  }
  catch(NullPointerException e) {
	       return "E";
		} 
}
}

