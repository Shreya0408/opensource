public class pair {
	String fname;
	String lname;
	public pair(String fname,String lname) {
		this.fname=fname;
		this.lname=lname;
		
	}
	public String getfname() {
		return fname;
	}
   public String getlname() {
	   return lname;
   }
}
