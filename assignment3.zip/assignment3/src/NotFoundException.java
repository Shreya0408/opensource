public class NotFoundException extends Exception {

}
